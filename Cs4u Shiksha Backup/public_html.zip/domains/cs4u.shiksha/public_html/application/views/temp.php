<html>
	<head>
		<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
		<script src="../../public/js/feed.js"></script>
	</head>
			
	<body>
	    
	   	<div ng-app="MyApp">
			<div ng-controller="MyCtrl">
				{{hello}}
    			{{feed}}
			</div>
		</div>
	</body>
</html>