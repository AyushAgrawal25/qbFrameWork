<qb-menus qb-menu-type="top">
    <qb-menu>
        <qb-menus qb-menu-type="sub">
            <qb-menu></qb-menu>
            <qb-menu></qb-menu>
            <qb-menu></qb-menu>
        </qb-menus>
    </qb-menu>
    <qb-menu></qb-menu>
    <qb-menu></qb-menu>
    <qb-menu></qb-menu>
    <qb-menu>
        <qb-menus qb-menu-type="sub">
            <qb-menu></qb-menu>
            <qb-menu></qb-menu>
            <qb-menu></qb-menu>
        </qb-menus>
    </qb-menu>
</qb-menus>