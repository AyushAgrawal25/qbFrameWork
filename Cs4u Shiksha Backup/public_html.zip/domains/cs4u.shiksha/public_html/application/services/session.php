<?php include '../models/index.php';?>
<?php
echo true;
?>