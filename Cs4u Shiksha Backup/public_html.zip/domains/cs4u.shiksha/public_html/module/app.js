var myApp=angular.module("myApp",['qbmod']);
myApp.controller("myCtrl",function(){});