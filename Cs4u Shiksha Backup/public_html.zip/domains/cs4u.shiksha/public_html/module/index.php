<html>
    <head>
        <title>registration</title>
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="app.js"></script>
		<script src="module.js"></script>
    </head>
    <body ng-app="myApp" mg-controller="myCtrl">
        <modtest></modtest>
        <?php echo 'hi';?>
    </body>
</html>