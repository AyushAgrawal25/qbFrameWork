<?php
    $val=array("userId"=>1,"id"=> 1,"title"=>"delectus aut autem","completed"=> false);
  echo json_encode($val);
?>