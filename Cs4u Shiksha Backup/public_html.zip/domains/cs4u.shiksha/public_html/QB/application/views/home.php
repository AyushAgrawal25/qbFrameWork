<div layout="column" layout-padding ng-cloak>
  <md-content>
    <md-grid-list md-cols="2" md-gutter="0" md-row-height="4:3">
    <md-grid-tile class="tile1">
      
      <md-button class="md-icon-button md-primary homemenu" ng-click="getBusiness('HOTEL')" aria-label="Hotels">
        <font size='50'><i class="fa fa-cutlery" aria-hidden="true"></i></font>
    </md-button>
    <md-grid-tile-footer>
        Hotel
      </md-grid-tile-footer>
    </md-grid-tile>
    <md-grid-tile class="tile2">
    
    <md-button class="md-icon-button md-primary homemenu" ng-click="getBusiness('HOTEL')" aria-label="Hotels">
      <font size='50'><i class="fa fa-bed" aria-hidden="true"></i></font>
  </md-button>
  </md-grid-tile >
  <md-grid-tile class="tile3">
  
  <md-button class="md-icon-button md-primary homemenu" ng-click="getBusiness('HOTEL')" aria-label="Hotels">
    <font size='50'><i class="fa fa-shopping-bag" aria-hidden="true"></i></font>
</md-button>
</md-grid-tile>
<md-grid-tile class="tile4">

<md-button class="md-icon-button md-primary homemenu" ng-click="getBusiness('HOTEL')" aria-label="Hotels">
  <font size='50'><i class="fa fa-shirtsinbulk" aria-hidden="true"></i></font>
</md-button>
</md-grid-tile>
<md-grid-tile class="tile5">

<md-button class="md-icon-button md-primary homemenu" ng-click="getBusiness('HOTEL')" aria-label="Hotels">
  <font size='50'><i class="fa fa-calendar" aria-hidden="true"></i></font>
</md-button>
</md-grid-tile>
<md-grid-tile class="tile6">

<md-button class="md-icon-button md-primary homemenu" ng-click="getBusiness('HOTEL')" aria-label="Hotels">
  <font size='50'><i class="fa fa-paw" aria-hidden="true"></i></font>
</md-button>
</md-grid-tile>
  </md-grid-list>
  </md-content>
</div>