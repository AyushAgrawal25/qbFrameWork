
    <form>
        <input type='text' ng-model="data.fName">
        <input type='text' ng-model="data.lName">
        <input type='text' ng-model="data.age">
        <input type='text' ng-model="data.d.o.b">
        <input type='text' ng-model="data.contact no.">
        <h1>ACADEMIC INFORMATION</h1>
        <input type='text' ng-model="data.school/college">
        <input type='text' ng-model="data.city">
        <input type='text' ng-model="data.name of school/college">
        <input type='text' ng-model="data.standard of student">
    
   <button ng-click='user()'>click</button>
   {{result}}
    </form>
