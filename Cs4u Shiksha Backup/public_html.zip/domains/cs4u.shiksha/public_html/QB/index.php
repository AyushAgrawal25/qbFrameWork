<?php
	header('Location:application/views')
?>