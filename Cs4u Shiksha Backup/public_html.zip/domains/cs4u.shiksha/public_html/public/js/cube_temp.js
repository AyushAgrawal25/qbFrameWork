myApp.factory('qbTemp',function(){
    return {
          call:function(){
              console.log("It Worked");
          }
    };
});