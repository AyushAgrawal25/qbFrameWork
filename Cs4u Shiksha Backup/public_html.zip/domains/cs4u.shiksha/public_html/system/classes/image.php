<?php

class image
{
	function __construct()
	{
		$errormsg="";
		ini_set('gd.jpeg_ignore_warning','PHP_INI_ALL');
	}
	//cropping image
	public function crop()
	{
		
	}
	public function resize()
	{
	
	}
	public function compress()
	{
	
	}
	
	
}