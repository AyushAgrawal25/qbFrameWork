<?php include 'base.php';?>
<?php
class Controller extends Base
{
	public function __construct()
	{
		parent::__construct();
	}
}