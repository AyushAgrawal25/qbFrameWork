var myApp = angular.module("myApp", ['ngMessages']);
myApp.controller('myCtrl', function($scope) {
    $scope.data1=["ayush","ishan","aman"];
    $scope.countries=["Afghanistan","Albania","Algeria","Andorra","Angola","Anguilla","Antigua & Barbuda","Argentina","Armenia","Aruba","Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bermuda","Bhutan","Bolivia","Bosnia & Herzegovina","Botswana","Brazil","British Virgin Islands","Brunei","Bulgaria","Burkina Faso","Burundi","Cambodia","Cameroon","Canada","Cape Verde","Cayman Islands","Central Arfrican Republic","Chad","Chile","China","Colombia","Congo","Cook Islands","Costa Rica","Cote D Ivoire","Croatia","Cuba","Curacao","Cyprus","Czech Republic","Denmark","Djibouti","Dominica","Dominican Republic","Ecuador","Egypt","El Salvador","Equatorial Guinea","Eritrea","Estonia","Ethiopia","Falkland Islands","Faroe Islands","Fiji","Finland","France","French Polynesia","French West Indies","Gabon","Gambia","Georgia","Germany","Ghana","Gibraltar","Greece","Greenland","Grenada","Guam","Guatemala","Guernsey","Guinea","Guinea Bissau","Guyana","Haiti","Honduras","Hong Kong","Hungary","Iceland","India","Indonesia","Iran","Iraq","Ireland","Isle of Man","Israel","Italy","Jamaica","Japan","Jersey","Jordan","Kazakhstan","Kenya","Kiribati","Kosovo","Kuwait","Kyrgyzstan","Laos","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania","Luxembourg","Macau","Macedonia","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Mauritania","Mauritius","Mexico","Micronesia","Moldova","Monaco","Mongolia","Montenegro","Montserrat","Morocco","Mozambique","Myanmar","Namibia","Nauro","Nepal","Netherlands","Netherlands Antilles","New Caledonia","New Zealand","Nicaragua","Niger","Nigeria","North Korea","Norway","Oman","Pakistan","Palau","Palestine","Panama","Papua New Guinea","Paraguay","Peru","Philippines","Poland","Portugal","Puerto Rico","Qatar","Reunion","Romania","Russia","Rwanda","Saint Pierre & Miquelon","Samoa","San Marino","Sao Tome and Principe","Saudi Arabia","Senegal","Serbia","Seychelles","Sierra Leone","Singapore","Slovakia","Slovenia","Solomon Islands","Somalia","South Africa","South Korea","South Sudan","Spain","Sri Lanka","St Kitts & Nevis","St Lucia","St Vincent","Sudan","Suriname","Swaziland","Sweden","Switzerland","Syria","Taiwan","Tajikistan","Tanzania","Thailand","Timor L'Este","Togo","Tonga","Trinidad & Tobago","Tunisia","Turkey","Turkmenistan","Turks & Caicos","Tuvalu","Uganda","Ukraine","United Arab Emirates","United Kingdom","United States of America","Uruguay","Uzbekistan","Vanuatu","Vatican City","Venezuela","Vietnam","Virgin Islands (US)","Yemen","Zambia","Zimbabwe"];
    $scope.data2=["aman","raj","sanskar"];
	$scope.functest=function()
	{
		alert($scope.firstname);
	}
	$scope.combo=function()
	{
	    alert("sdajhgku");
	}
	$scope.myClick=function(data)
	{
	   $scope.value=data;
	}
	$scope.myClickFun=function(data)
	{
	    alert("worked");
	}
	$scope.element;
	
});

myApp.service('qbBasics',function(){
    this.classCons= function (classes) {
        var allClass=classes.split(',');
        var classL="";
        var k=0;
        angular.forEach(allClass, function(value, key){
            if(!(classL))
                classL=allClass[k];
            else
                classL=classL+" "+allClass[k];
            k++;
        });
        return classL;
    }
    this.findParent=function(pElement,pName){
        var par=pElement.parent();
        var con=true;
        var parName=pName.toUpperCase();
        var reqElement;
        while(con)
        {
            if((par[0].nodeName)===parName)
            {
                reqElement=par;
                con=false;
            }
            else if((par[0].nodeName)==="BODY")
            {
                con=false;
                reqElement=undefined;
            }
            else
                par=par.parent();
        }
        if(reqElement===undefined)
            alert("Undefined Parent Name");
        return reqElement;
    }
    this.findChildren=function(cElement,cName){
        var child=cElement.children();
        var reqChildren=[];
        var con=true;
        var found=false;
        while(con)
        {
            if(typeof child !== 'undefined' && child.length > 0)
            {
                var i=0;
                var j=0;
                angular.forEach(child, function(value, key){
                    if((angular.element(value)[0].nodeName)===(cName.toUpperCase()))
                    {
                        reqChildren[i]=child[j];
                        i++;
                        found=true;
                    }
                    j++;
                });
                if(found)
                {
                    con=false;
                }
                else
                {
                    child=child.children();    
                }
            }
            else
            {
                con=false;
                //alert("Undefined Children NodeName");
            }
        }
        return reqChildren;
    }
    this.findElement=function(eName){
        var qbContainer=angular.element(document.querySelector(eName));
        var con=true;
        var found=false;
        var reqElement;
        /*var child=qbContainer.children();
        while(con)
        {
            if(typeof child !== 'undefined' && child.length > 0)
            {
                var i=0;
                angular.forEach(child, function(value, key){
                    if((angular.element(value)[0].nodeName)===(eName.toUpperCase()))
                    {
                       reqElement=child[i];
                        found=true;
                    }
                    i++;
                });
                if(found)
                {
                    con=false;
                }
                else
                {
                    child=child.children();    
                }
            }
            else
            {
                con=false;
                alert("Undefined Element NodeName");
            }
        }*/
        return qbContainer;
    }
    
    this.findQbChildren=function(eObject){
        var child=eObject.children();
        var reqChildren=[];
        var con=true;
        var found=false;
        while(con)
        {
            if(typeof child !== 'undefined' && child.length > 0)
            {
                var i=0;
                var j=0;
                angular.forEach(child, function(value, key){
                    var childName=angular.element(value)[0].nodeName;
                    if(((childName[0])==="Q")&&((childName[1])==="B")&&((childName[2])==="-"))
                    {
                        reqChildren[i]=child[j];
                        i++;
                        found=true;
                    }
                    j++;
                });
                if(found)
                {
                    con=false;
                }
                else
                {
                    child=child.children();    
                }
            }
            else
            {
                con=false;
                //alert("Undefined Children NodeName");
            }
        }
        return reqChildren;
    }
    
    this.isQbType=function(eName){
        var eleName=angular.element(eName)[0].nodeName;
        if(((eleName[0])==="Q")&&((eleName[1])==="B")&&((eleName[2])==="-"))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    this.contentsAlign=function(elem,hAlign,vAlign,widthType,contentsTotalWidth){
        var contsWidth=[];
        var contents=angular.element(elem).children();
        if(hAlign)
        {
            if(hAlign=="left")
            {
                angular.forEach(contents, function(vCont, kCont){
                     angular.element(vCont)[0].style.float="left";
                 });
            }
            
            else if(hAlign==="middle")
            {
                if(widthType==="responsive")
                {
                    var totalWidth=0;
	                var i=0;
	                angular.forEach(contents, function(vCont, kCont){
	                    var thisWidth=parseFloat(window.getComputedStyle(angular.element(vCont)[0], null).getPropertyValue('width'));
    	                totalWidth=totalWidth+thisWidth;
    	                contsWidth[i]=thisWidth;
    	                i++;
	                });
	                var parentWidth=parseFloat(window.getComputedStyle(angular.element(elem)[0], null).getPropertyValue('width'));
	                var paddingWidth=(parentWidth-totalWidth)/2;
	                var paddingPer=(paddingWidth/parentWidth)*100;
	                angular.element(elem).css("padding-left",paddingPer+"%");
	                angular.element(elem).css("padding-right",paddingPer+"%");
	                i=0;
	                angular.forEach(contents, function(vCont, kCont){
	                    var widthPer=(contsWidth[i]/totalWidth)*100;
	                    angular.element(vCont).css("width",widthPer+"%");
	                    i++;
	                });
                }
                else if(widthType==="static")
                {
                    var totalWidth=0;
	                var i=0;
	                angular.forEach(contents, function(vCont, kCont){
	                    var thisWidth=parseFloat(window.getComputedStyle(angular.element(vCont)[0], null).getPropertyValue('width'));
    	                totalWidth=totalWidth+thisWidth;
    	                contsWidth[i]=thisWidth;
    	                i++;
	                });
	                var parentWidth=parseFloat(window.getComputedStyle(angular.element(elem)[0], null).getPropertyValue('width'));
	                var paddingWidth=(parentWidth-totalWidth)/2;
	                angular.element(elem).css("padding-left",paddingWidth+"px");
	                angular.element(elem).css("padding-right",paddingWidth+"px");
                }
            }
            
            else if(hAlign==="right")
            {
                angular.forEach(contents, function(vCont, kCont){
                     angular.element(vCont)[0].style.float="right";
                 });
            }
        }
        
        if(vAlign)
        {
            
        }
    }
    
    this.contentsAlignResize=function(elem,hAlign,vAlign,widthType,contentsTotalWidth){
        var contsWidth=[];
        var contents=angular.element(elem).children();
        if(hAlign)
        {
            if(hAlign=="left")
            {
                angular.forEach(contents, function(vCont, kCont){
                     angular.element(vCont)[0].style.float="left";
                 });
            }
            
            else if(hAlign==="middle")
            {
                if(hAlign==="middle")
		            {
		                if(widthType==="static")
		                {
		                    if(contentsTotalWidth)
		                    {
		                        var parentWidth=parseFloat(window.getComputedStyle(angular.element(elem)[0], null).getPropertyValue('width'));
		                        var paddingWidth=(parentWidth-contentsTotalWidth)/2;
	                            angular.element(elem).css("padding-left",paddingWidth+"px");
        		                angular.element(elem).css("padding-right",paddingWidth+"px");
		                    }
		                }
		            }
            }
            
            else if(hAlign==="right")
            {
                angular.forEach(contents, function(vCont, kCont){
                     angular.element(vCont)[0].style.float="right";
                 });
            }
        }
        
        if(vAlign)
        {
            
        }
    }
});

myApp.service('qbDataBase',qbDataBase);
qbDataBase.$inject=['$http'];
function qbDataBase($http)
{
    this.arrayData= function (tabName,colName,fColName,fVal) {
        var arrData;
        var filter_data={table:tabName,column:colName,fcolumn:fColName,fvalue:fVal};
        
        $http({
        method:'POST',url:'../controllers/filter.php',data:filter_data
            }).then(function mySucces(response){
               arrData=response.data;
               alert(arrData);
            },function myError(response){
                alert(response.statusText);
        });
    }   
}

myApp.directive('qbdb',['qbDataBase', function(qbDataBase) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    qbDataBase.arrayData("location_master","Location_Master_State","Location_Master_Country","India");
		},
		template: function(element,attr){
		    return "<div></div>"
		}
	}
}]);
 
 myApp.directive('qbContainer', function() {
    return {
        scope:{},
		transclude: true,
		link: function(scope,element,attr){
		    var scHeight= window.innerHeight;
		    var cHeight=0;
		    var rHeight=0;
		    var child=angular.element(element).children().children();
		    if(window.innerWidth>600)
		    {
        	    angular.forEach(child, function(value, key){
        	        if(((angular.element(value)[0].nodeName)=="QB-TOP-MENUS")||((angular.element(value)[0].nodeName)=="QB-HEADER"))
        	            cHeight=cHeight + angular.element(value).children()[0].offsetHeight;
        	        else
        	            cHeight=cHeight + angular.element(value)[0].offsetHeight;
        	    });
        	    rHeight=scHeight-cHeight;
        	    angular.forEach(child, function(value, key){
        	        if((angular.element(value)[0].nodeName)==="QB-ROW")
        	        {
        	            angular.element(value).children().css('height',rHeight);
        	        }
        	    });
		    }
		    var win = angular.element(window);
		    win.bind('resize', function () {
		        var scWidth= window.innerWidth;
		        var scHeight= window.innerHeight;
		        var cHeight=0;
    	        if(scWidth>600)
		        {
		            angular.forEach(child, function(value, key){
            	    if(((angular.element(value)[0].nodeName)=="QB-TOP-MENUS")||((angular.element(value)[0].nodeName)=="QB-HEADER"))
            	        cHeight=cHeight + angular.element(value).children()[0].offsetHeight;
            	    else
            	        cHeight=cHeight + angular.element(value)[0].offsetHeight;
            	   });
            	   rHeight=scHeight-cHeight;
		           angular.forEach(child, function(value, key){
            	        if((angular.element(value)[0].nodeName)==="QB-ROW")
            	        {
            	            angular.element(value).children().css('height',rHeight);
            	        }
            	    }); 
		        }
		        else if(scWidth<600)
		        {
		            angular.forEach(child, function(value, key){
            	        if((angular.element(value)[0].nodeName)==="QB-ROW")
            	        {
            	            angular.element(value).children().css('height','100%');
            	        }
            	    });
		        }
            });
		},
		template: function(element,attr){
		    return "<div ng-transclude></div>";    
		}
	}
});

 
myApp.directive('qbFormInput',['qbBasics',  function(qbBasics) {
    return {
		scope: {
		    ngmodel:'='
		},
		transclude: true,
		link: function(scope,element,attr){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    angular.element(element).children().attr("name","ayush");
		    scope.validate=function()
		    {
		        var str = scope.ngmodel;
                var patt = new RegExp(attr.expression);
                var res = patt.test(str);
		    }
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-input-container\"> <span class=\"qb-input-label\"></span> <input type=\"text\" name=\""+attr.name+"\" ng-model=\"ngmodel\" class=\"qb-input\" ng-keyup=\"validate()\" required> <div class=\"qb-input-message\" ng-transclude> </div> </div>";
		}
	}
}]);

myApp.directive('qbFlex',['qbBasics',  function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    var height=0;
		    scope.loadfun=function(){
		        angular.element(element).children().append(transclude());
		        angular.element(element).children().append("<div style=\"clear:both\"></div>");
		        var childs=angular.element(element).children().children();
		        angular.forEach(childs, function(value, key){
                    height=height+(angular.element(value)[0].offsetHeight);
                });
		    };
		},
		template: function(element,attr){
		    return "<div ng-if=\"loadfun\" ng-init=\"loadfun()\" ng-click=\"clickfun()\"></div>";
		}
	}
}]);

myApp.directive('qbFilter',qbFilter);
qbFilter.$inject=['$http'];
function qbFilter($http)
{
	return {
		restrict: 'E',
		scope:{
		    val: "=",
		    fvar: "="
		},
		link: function(scope,element,attr){
		    scope.datafetch=function(fvariable){
		        if(!attr.fvalue)
		        {
		            if(fvariable)
                    {
                        if(attr.defaultSelect)
                        {
                            var filter_data={table:attr.table,column:attr.column,fcolumn:attr.fcolumn,fvalue:fvariable};
            		        
            	            $http({
                            method:'POST',url:'../controllers/filter.php',data:filter_data
                                }).then(function mySucces(response){
                                    angular.element(element).children().scope().responses=response.data;
                                    //alert(scope.responses);
                                },function myError(response){
                                    alert(response.statusText);
                            });
                        }
                        else
                        {
                            var filter_data={table:attr.table,column:attr.column,fcolumn:attr.fcolumn,fvalue:fvariable};
        		            angular.element(element).children().children().children().attr("hidden","");
        		            $http({
                            method:'POST',url:'../controllers/filter.php',data:filter_data
                                }).then(function mySucces(response){
                                    angular.element(element).children().scope().responses=response.data;
                                    if(angular.element(element).children().scope().responses)
                                    {
                                        angular.element(element).children().children().children().html("");
                                        angular.element(element).children().children().scope().val=angular.element(element).children().scope().responses[0];
                                        angular.element(element).children().scope().changefun();
                                    }
                                },function myError(response){
                                    alert(response.statusText);
                            });
                        }
                    }
                    else
                    {
                        angular.element(element).children().scope().changefun();
                    }
		        }
		    };
		    
		    scope.datadetach=function(fvariable){
		        angular.element(element).children().scope().responses="";
		        var myFilters = angular.element(document.querySelectorAll("qb-filter"));
    		    angular.forEach(myFilters, function(value, key){
    		        if(angular.element(value).attr("fetch-id")==attr.filterId)
    		        {
    		            angular.element(value).children().scope().datadetach(fvariable);
    		        }
    		    });
		    };
		    scope.changefun=function(){
		        scope.val=angular.element(element).children().children().scope().val;
		        var fvariable=angular.element(element).children().children().scope().val;
		        angular.element(element).children().scope().findfilter(fvariable);
		    };
		    scope.clickfun=function(){
		        
		    };
		    scope.findfilter=function(fvariable){
		        var myFilters = angular.element(document.querySelectorAll("qb-filter"));
    		    angular.forEach(myFilters, function(value, key){
    		        if(angular.element(value).attr("fetch-id")==attr.filterId)
    		        {
    		            //alert(angular.element(value).attr("filter-id"));
    		            if(fvariable)
    		                angular.element(value).children().scope().datafetch(fvariable);
    		            else
    		                angular.element(value).children().scope().datadetach(fvariable);
    		        }
    		    });
		    };
		    scope.dataload=function(){
		        if(attr.fvalue)
		        {
		            if(attr.defaultSelect)
        		    {
        		        //try to make default selection i got one solution .
            		    var filter_data={table:attr.table,column:attr.column,fcolumn:attr.fcolumn,fvalue:attr.fvalue};
    		        
    		            $http({
                        method:'POST',url:'../controllers/filter.php',data:filter_data
                            }).then(function mySucces(response){
                                angular.element(element).children().scope().responses=response.data;
                            },function myError(response){
                                alert(response.statusText);
                        });
        		    }
        		    else
        		    {
        		        var filter_data={table:attr.table,column:attr.column,fcolumn:attr.fcolumn,fvalue:attr.fvalue};
    		            angular.element(element).children().children().children().attr("hidden","");
    		            $http({
                        method:'POST',url:'../controllers/filter.php',data:filter_data
                            }).then(function mySucces(response){
                                angular.element(element).children().scope().responses=response.data;
                                if(angular.element(element).children().scope().responses)
                                {
                                    angular.element(element).children().children().children().html("");
                                    angular.element(element).children().children().scope().val=angular.element(element).children().scope().responses[0];
                                    angular.element(element).children().scope().changefun();
                                }
                            },function myError(response){
                                alert(response.statusText);
                        });
        		    }
		        }
		        else if(!attr.defaultSelect)
		        {
		            angular.element(element).children().children().children().html("");
		        }
		    };
		},
		template: function(element,attr){
	        return "<div ng-if=\"dataload\" ng-init=\"dataload()\" > <select ng-model=\"val\" ng-change=\"changefun()\"> <option value=\"\">"+attr.defaultSelect+"</option> <option ng-repeat=\"response in responses\" value={{response}}>{{response}}</option></select> </div>";
		}
	}
}

myApp.directive('qbAccordions',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    
		    var qbAccordions=qbBasics.findChildren(angular.element(element),"QB-ACCORDION");
		    var qbAccHeadings=qbBasics.findChildren(angular.element(element),"QB-ACC-HEADING");
		    var qbAccContents=qbBasics.findChildren(angular.element(element),"QB-ACC-CONTENT");
		    scope.qbidies=[];
		    var i=0;
		    angular.forEach(qbAccordions, function(value, key){
		        scope.qbidies.push("qb-acc-"+i);
		        angular.element(qbAccordions[i]).children().attr("qb-acc-id",scope.qbidies[i]);
		        angular.element(qbAccHeadings[i]).children().attr("qb-acc-id",scope.qbidies[i]);
		        angular.element(qbAccContents[i]).children().attr("qb-acc-id",scope.qbidies[i]);
		        i++;
		    });
	        scope.initiatefun=function(accId){
	            angular.forEach(qbAccordions, function(value, key){
	                if((angular.element(value).children().attr("qb-acc-id"))==accId)
	                {
	                    if((angular.element(value).children().scope().state)==="close")
	                    {
	                        angular.element(value).children().scope().openacc();
	                    }
	                    else
	                    {
	                        angular.element(value).children().scope().closeacc();
	                    }
	                }
	                else
	                {
	                    angular.element(value).children().scope().closeacc();
	                }
    		    });
		    };
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-accordions\" ng-transclude></div>";
		}
	}
}]);
myApp.directive('qbAccordion',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
		    scope.state="close";
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    scope.openacc=function(){
		        scope.state="open";
		        var acCont=qbBasics.findChildren(angular.element(element),"qb-acc-content");
		        angular.element(acCont).children().addClass("qb-accordion-content-open").removeClass("qb-accordion-content-close");
		    };
		    
		    scope.closeacc=function(){
		        scope.state="close";
		        var acCont=qbBasics.findChildren(angular.element(element),"qb-acc-content");
		        angular.element(acCont).children().addClass("qb-accordion-content-close").removeClass("qb-accordion-content-open");
		    };
		    if(attr.default==="open")
		    {
	            angular.element(element).children().scope().openacc();
		    }
		    else
		    {
		        angular.element(element).children().scope().closeacc();
		    }
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-accordion\" ng-transclude></div>";
		}
	}
}]);
myApp.directive('qbAccHeading',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
	        if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    
		    scope.clickfun=function(){
		        var accs=qbBasics.findParent(angular.element(element),"qb-accordions");
		        var accId=angular.element(element).children().attr("qb-acc-id");
		        angular.element(accs).children().scope().initiatefun(accId);
		    };
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-accordion-heading\" ng-click=\"clickfun()\" ng-transclude ></div>";
		}
	}
}]);
myApp.directive('qbAccContent',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-accordion-content\" ng-transclude></div>";
		}
	}
}]);

//last seen on 22-07-2019
//heading styling
myApp.directive('qbTabs',['qbBasics', function(qbBasics) {
    return {
	    scope: {},
		transclude: true,
		link: function(scope,element,attr){
		    var qbTabs=qbBasics.findChildren(angular.element(element),"QB-TAB");
		    var qbTabHeadings=qbBasics.findChildren(angular.element(element),"QB-TAB-HEADING");
		    var qbTabContents=qbBasics.findChildren(angular.element(element),"QB-TAB-CONTENT");
		    var numOfHeadings=qbTabHeadings.length;
		    scope.qbidies=[];
		    var i=0;
		    angular.forEach(qbTabs, function(value, key){
		        scope.qbidies.push("qb-tab-"+i);
		        angular.element(qbTabs[i]).children().attr("qb-tab-id",scope.qbidies[i]);
		        angular.element(qbTabHeadings[i]).children().attr("qb-tab-id",scope.qbidies[i]);
		        angular.element(qbTabContents[i]).children().attr("qb-tab-id",scope.qbidies[i]);
		        i++;
		    });
		    
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    
            var headingAllign="";
            var headingSizeType="";
            var headingTotalWidth="";
            var headingComputedWidth="";
            var headingGivenWidth="";
            
            var headingPaddingRight="";
            var headingPaddingLeft="";
            var headingMarginRight="";
            var headingMarginLeft="";
            var headingBorderRight="";
            var headingBorderLeft="";
            
            if(attr.qbHeadingsStyle)
		    {
		        var qbHeadStyles=attr.qbHeadingsStyle.split(";");
		        angular.forEach(qbHeadStyles, function(value, key){
		            var qbHeadStyle="";
		            qbHeadStyle=value.split(":");
		            if((qbHeadStyle[0])==="allign")
		            {
		                if((qbHeadStyle[1])==="left")
		                {
		                    headingAllign="left";
		                }
		                else if((qbHeadStyle[1])==="right")
		                {
		                    headingAllign="right";
		                }
		                else if((qbHeadStyle[1])==="centre")
		                {
		                    headingAllign="centre";
		                }
		            }
		            else if((qbHeadStyle[0])==="size")
		            {
		                if((qbHeadStyle[1])==="equal")
		                {
		                    headingSizeType="equal";
		                    //angular.element(element).children().scope().headingSize(headSize,"equal");
		                }
		                else if((qbHeadStyle[1])==="auto")
		                {
		                    headingSizeType="auto";
		                }
		                else if((qbHeadStyle[1])==="fullfill")
		                {
		                    headingSizeType="fullfill";
		                }
		            }
		            else if((qbHeadStyle[0])==="total-width") 
		            {
		                if(qbHeadStyle[1])
		                {
		                    headingTotalWidth=parseFloat(qbHeadStyle[1]);
		                }
		            }
		        });
		        if(headingTotalWidth)
		        {
    	            var headingCont=angular.element(angular.element(element).children().children()[0]);
    	            headingComputedWidth=parseFloat(window.getComputedStyle(headingCont[0], null).getPropertyValue('width'));
    	            headingGivenWidth=headingComputedWidth/100*headingTotalWidth;
    	            
    	            headingPaddingRight=parseFloat(window.getComputedStyle(headingCont[0], null).getPropertyValue('padding-right'));
    	            headingPaddingLeft=parseFloat(window.getComputedStyle(headingCont[0], null).getPropertyValue('padding-left'));
		        }
		        else
		        {
    	            var headingCont=angular.element(angular.element(element).children().children()[0]);
    	            headingComputedWidth=parseFloat(window.getComputedStyle(headingCont[0], null).getPropertyValue('width'));
    	            headingGivenWidth=headingComputedWidth;
    	            
    	            headingPaddingRight=parseFloat(window.getComputedStyle(headingCont[0], null).getPropertyValue('padding-right'));
    	            headingPaddingLeft=parseFloat(window.getComputedStyle(headingCont[0], null).getPropertyValue('padding-left'));
		        }
		    } 
		    
		    
		    var headingSize=0;
		    scope.headingStyle=function(headWidth){
		        //size type
		        if(headingSizeType==="fullfill")
		        {
		            if(headingTotalWidth)
        	        {
        	            var headingWidth=(headingGivenWidth)/(numOfHeadings);
        	            
        	            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		                angular.forEach(headingDivs, function(value, key){
        	                var thisPaddingLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-left'));
        	                var thisPaddingRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-right'));
        	                var thisMarginLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-left'));
        	                var thisMarginRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-right'));
        	                var thisBorderLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-left'));
        	                var thisBorderRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-right'));
        	                
        	                var thisCalculatedWidth=headingWidth-(thisPaddingLeft+thisPaddingRight+thisMarginLeft+thisMarginRight+thisBorderLeft+thisBorderRight);
        	                angular.element(value).css("width",thisCalculatedWidth+"px");
        	            });
        	        }
        	        else
        	        {
        	            var headingWidth=(headingGivenWidth)/(numOfHeadings);
        	            
        	            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		                angular.forEach(headingDivs, function(value, key){
        	                var thisPaddingLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-left'));
        	                var thisPaddingRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-right'));
        	                var thisMarginLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-left'));
        	                var thisMarginRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-right'));
        	                var thisBorderLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-left'));
        	                var thisBorderRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-right'));
        	                
        	                var thisCalculatedWidth=headingWidth-(thisPaddingLeft+thisPaddingRight+thisMarginLeft+thisMarginRight+thisBorderLeft+thisBorderRight);
        	                angular.element(value).css("width",thisCalculatedWidth+"px");
        	            });
        	        }
		        }
		        else if(headingSizeType==="equal")
		        {
		            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		            if(headWidth>headingSize)
    		        {
    		            headingSize=headWidth;
    		        }
    		        angular.forEach(headingDivs, function(value, key){
    	                //all values of padding margin border
    	                var thisPaddingLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-left'));
    	                var thisPaddingRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-right'));
    	                var thisMarginLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-left'));
    	                var thisMarginRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-right'));
    	                var thisBorderLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-left'));
    	                var thisBorderRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-right'));
    	                
    	                var thisTotalWidth=thisPaddingLeft+thisPaddingRight+thisMarginLeft+thisMarginRight+thisBorderLeft+thisBorderRight+headingSize;
    	                angular.element(value).css("width",thisTotalWidth+"px");
    	            });   
		        }
		        else if(headingSizeType==="auto")
		        {
		            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		            angular.forEach(headingDivs, function(value, key){
		                angular.element(value).css("width","auto");
    	            });
		        }
		        
		        //total width
		        if(headingTotalWidth)
		        {
		            
		        }
		        
		        // allignment
		        if(headingAllign==="left")
		        {
		            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		            angular.forEach(headingDivs, function(value, key){
		                angular.element(value).css("float","left");
    	            });
    	            var paddingRight=(headingComputedWidth-headingGivenWidth)+headingPaddingRight;
    	            angular.element(angular.element(element).children().children()[0]).css("padding-right",paddingRight+"px");
    	            
    	        }
		        else if(headingAllign==="right")
		        {
		            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		            angular.forEach(headingDivs, function(value, key){
		                angular.element(value).css("float","left");
    	            });
    	            var paddingLeft=(headingComputedWidth-headingGivenWidth)+headingPaddingLeft;
    	            angular.element(angular.element(element).children().children()[0]).css("padding-left",paddingLeft+"px");
		        }
		        else if(headingAllign==="centre")
		        {
		            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		            angular.forEach(headingDivs, function(value, key){
		                angular.element(value).css("float","left");
    	            });
    	            var paddingRight=((headingComputedWidth-headingGivenWidth)/2)+headingPaddingRight;
    	            var paddingLeft=((headingComputedWidth-headingGivenWidth)/2)+headingPaddingLeft;
    	            angular.element(angular.element(element).children().children()[0]).css("padding-right",paddingRight+"px");
    	            angular.element(angular.element(element).children().children()[0]).css("padding-left",paddingLeft+"px");
		        }
		    };
		    
		    scope.headingloadfun=function(qbId){
		        var times=0;
		        var defattr=false;
		        var qbtabid="";
		        angular.forEach(qbTabs, function(value, key){
        	        if(((angular.element(value).attr("default"))==="open")&&(!times))
        	        {
        	           defattr=true;
        	           qbtabid=angular.element(value).children().attr("qb-tab-id");
        	           times=1;
        	        }
        	    });
        	    if(!(defattr))
        	    {
        	        qbtabid=angular.element(qbTabs[0]).children().attr("qb-tab-id");
        	    }
    		    angular.forEach(qbTabHeadings, function(value, key){
    		        var headId=angular.element(value).children().attr("qb-tab-id");
    		        if(headId===qbId)
    		        {
    		            angular.element(value).children().scope().openHeadingClass();
    		            var tabHeading=angular.element(value).children().scope().getHeading();
    		            var tabHeadingClass=angular.element(value).children().scope().headingClass();
    		            var thisHeadings=angular.element(element).children().children().children();
    		            angular.forEach(thisHeadings, function(value1, key1){
    		                if(angular.element(value1).scope().qbid)
    		                {
    		                    if((angular.element(value1).scope().qbid)===qbId)
    		                    {
    		                        angular.element(value1).attr("qb-tab-id",qbId);
    		                        angular.element(value1).addClass(tabHeadingClass);
    		                        angular.element(value1).append(tabHeading);
    		                        
    		                        var thisPaddingLeft=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('padding-left'));
                	                var thisPaddingRight=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('padding-right'));
                	                var thisMarginLeft=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('margin-left'));
                	                var thisMarginRight=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('margin-right'));
                	                var thisBorderLeft=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('border-left'));
                	                var thisBorderRight=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('border-right'));
                	                
                	                var thisTotalWidth=thisPaddingLeft+thisPaddingRight+thisMarginLeft+thisMarginRight+thisBorderLeft+thisBorderRight+headingSize;
                	                angular.element(element).children().scope().headingStyle(thisTotalWidth);
    		                    }
    		                }
    		            }); 
    		        }
    		        if(qbtabid===qbId)
    		        {
    		            angular.element(element).children().scope().clickfun(qbtabid);
    		        }
    		    }); 
		    };
		    
		    scope.clickfun=function(qbId){
		        angular.forEach(qbTabContents, function(value, key){
		            if((angular.element(value).children().attr("qb-tab-id"))===qbId)
		            {
		                angular.element(value).children().scope().tabopen();          
		            }
		            else
		            {
		                angular.element(value).children().scope().tabclose();
		            }
		        }); 
		        var thisHeadings=angular.element(element).children().children().children();
                angular.forEach(thisHeadings, function(value1, key){
                    if(angular.element(value1).hasClass("qb-tab-heading-active"))
                    {
                        angular.element(value1).removeClass("qb-tab-heading-active").addClass("qb-tab-heading-inactive");
                    }
                    if(angular.element(value1).scope().qbid)
                    {
                        if((angular.element(value1).scope().qbid)===qbId)
                        {
                            angular.element(value1).addClass("qb-tab-heading-active").removeClass("qb-tab-heading-inactive");
                        }
                    }
                });
		    };
		},
		template: function(element,attr){ 
		    return  "<div class=\"qb-tabs\">"+ 
		                "<div class=\"qb-tab-headings\" style=\"overflow:hidden;width:auto\">"+
		                    " <div ng-repeat=\"qbid in qbidies\" class=\"qb-tab-heading qb-tab-heading-inactive ng-isolate-scope ng-scope\" ng-init=\"headingloadfun(qbid)\" ng-click=\"clickfun(qbid)\" ></div> "+
		                "</div>"+
		                "<div class=\"qb-tab-contents\" ng-transclude ></div>"+
		            "</div>";
		}
	}
}]);
myApp.directive('qbTab',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
	    
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-tab\" ng-transclude ></div>";
		}
	}
}]);
myApp.directive('qbTabHeading',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    scope.headingClass=function(){
		        if(attr.classes)
    		    {
    		        var headingClass=qbBasics.classCons(attr.classes);
    		        return headingClass;
    		    }
    		    else
    		    {
    		        return undefined;
    		    }
		    };
		    scope.getHeading=function(){
		        return transclude();
		    };
		    scope.openHeadingClass=function(){
		        if(attr.qbTabOpenClasses)
		        {
		            var headingClass=qbBasics.classCons(attr.qbTabOpenClasses);
    		        return headingClass;
		        }
		        else
		        {
		            return undefined; 
		        }
		    };
		},
		template: function(element,attr){ 
		    return "<div style=\"display:none;\" ng-transclude></div>";
		}
	}
}]);
myApp.directive('qbTabContent',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    scope.tabopen=function(){
		        angular.element(element).children().addClass("qb-tab-content-open").removeClass("qb-tab-content-close");
		    };
		    
		    scope.tabclose=function(){
		        angular.element(element).children().addClass("qb-tab-content-close").removeClass("qb-tab-content-open");
		    };
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-tab-content\" ng-transclude></div>";
		}
	}
}]);

// new version last seen on 28-04-2019
myApp.directive('qbAutoCompletes',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    scope.loadfun=function(){
		        var compNum=0;
		        angular.element(element).children().append(transclude());
		        var qbAutoCompletes=qbBasics.findChildren(angular.element(element).children(),"QB-AUTO-COMPLETE");
		        angular.forEach(qbAutoCompletes, function(value, key){
		            angular.element(value).children().attr("qb-auto-complete-id","qb-auto-complete-"+compNum);
		            compNum++;
		        });
		    };
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-auto-completes\" ng-if=\"loadfun\" ng-init=\"loadfun()\"></div>";
		}
	}
}]);

myApp.directive('qbAutoComplete',qbAutoComplete);
qbAutoComplete.$inject=['$http'];
function qbAutoComplete($http)
{
    return {
		scope: {
		    qbModel:"=",
		    qbScope:"="
		},
		transclude: true,
		link: function(scope,element,attr){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    var sugs ; 
		    scope.listloadfun=function(){
		        if(attr.qbDatas)
		        {   
		            sugs=attr.qbDatas.split(",");
		            scope.sugidies={};
        	        var sugNum=0;
        	        angular.forEach(sugs, function(value, key){
        		        scope.sugidies[sugNum]=sugNum;
        		        sugNum++;
        		    });
		        }
		        else if(scope.qbScope)
		        {
		            sugs=scope.qbScope;
		            scope.sugidies={};
        	        var sugNum=0;
        	        angular.forEach(sugs, function(value, key){
        		        scope.sugidies[sugNum]=sugNum;
        		        sugNum++;
        		    });
		        }
		        if((attr.table)&&(attr.column)&&(attr.fcolumn)&&(attr.fvalue))
		        {
		            var filter_data={table:attr.table,column:attr.column,fcolumn:attr.fcolumn,fvalue:attr.fvalue};
	        
    	            $http({
                    method:'POST',url:'../controllers/filter.php',data:filter_data
                        }).then(function mySucces(response){
                            sugs=response.data;
                            scope.sugidies={};
                	        var sugNum=0;
                	        angular.forEach(sugs, function(value, key){
                		        scope.sugidies[sugNum]=sugNum;
                		        sugNum++;
                		    });
                        },function myError(response){
                            alert(response.statusText);
                    });   
		        }
		    };
		    
		    var sugDivs={};
		    var matchingSugDivs={};
		    var focusSugs={};
		    var noOfSugs;
		    scope.sugloadfun=function(sugId){
		        angular.forEach(angular.element(element).children().children().children(), function(value, key){
    		        if((angular.element(value).scope().sugid)==sugId)
    		        {
    		            angular.element(value).attr("qb-suggestion-id","qb-suggestion-"+sugId);
    		            angular.element(value).attr("qb-suggestion",sugs[sugId]);
    		            sugDivs[sugId]=angular.element(element).children().children().children()[sugId];
    		        }
    		    });   
		    };
		    
		    scope.$watch('qbModel', function (newval, oldval) {
		        var inpVal=newval;
                var matchingSug=[];
		        var sugNum2=0;
		        if(toEmpty)
		        {
		            toEmpty=0;
		            angular.forEach(angular.element(element).children().children().children(), function(value, key){
		                angular.element(value).empty();
		                angular.element(value)[0].style.display="none";
		            });
		        }
		        else if((inpVal)&&(inpVal.length))
		        {
		            angular.forEach(sugs, function(value, key){
		                var req=0;
    		            for(var i=0; i<inpVal.length; i++)
    		            {   
    		                var sugUpper=value.toUpperCase();
    		                var inpUpper=inpVal.toUpperCase();
    		                if(!(sugUpper[i]===inpUpper[i]))
    		                {
    		                    req=0;
    		                    break;
    		                }
    		                else
    		                {
    		                    req=1;
    		                }
    		            }
    		            if(req)
    		            {
    		                matchingSug[sugNum2]=value;
    		            }
    		            else
    		            {
    		                matchingSug[sugNum2]="";
    		            }
		                sugNum2++;
		            });   
		            
		            if(matchingSug)
		            {
		                var matchNum=0;
		                var focusNum=0;
		                angular.forEach(matchingSug, function(value, key){
                            if(value)
                            {
                                if(value===(angular.element(sugDivs[matchNum]).attr("qb-suggestion")))
                                {
                                       //sugDivs[matchNum].css("display","block");
                                       var sugBVal="";
                                       var sugNVal="";
                                       for(var j=0; j<value.length; j++)
                    		           {
                    		                if((inpVal.length)<=j)
                    		                {
                    		                    sugNVal=sugNVal+value[j];
                    		                }
                    		                else
                    		                {
                    		                    sugBVal=sugBVal+value[j];
                    		                }
                    		           }
                    		           
                                       var sugChild=angular.element("<strong>"+sugBVal+"</strong>"+sugNVal+" ");
                                       angular.element(sugDivs[matchNum]).empty();
                                       angular.element(sugDivs[matchNum])[0].style.display="block";
                                       angular.element(sugDivs[matchNum]).append(sugChild);
                                       matchingSugDivs[focusNum]=angular.element(sugDivs[matchNum]);
                                       focusSugs[focusNum]=value;
                                       focusNum++;
                                       noOfSugs=focusNum;
                                }
                            }
                            else
                            {
                                angular.element(sugDivs[matchNum])[0].style.display="none";
                            }
                            matchNum++;
            		    });
            		    angular.forEach(matchingSugDivs, function(value, key){
        	                angular.element(value).removeClass("qb-autocomplete-suggestion-active");
        	            });
        	            focus=-1;
		            }
		        }
		        else
		        {
		            angular.forEach(angular.element(element).children().children().children(), function(value, key){
		                angular.element(value).empty();
		                angular.element(value)[0].style.display="none";
		            }); 
		        }
		    });
		    
		    scope.sugclickfun=function(sugId,actionType){
		        focus=-1;
		        if(actionType=="focus")
		        {
    	            toEmpty=1;
		            scope.qbModel=focusSugs[sugId];
		        }
		        else
		        {
		            toFocus=1;
		            scope.qbModel=sugs[sugId];
		        }
		        angular.element(element).children().children()[0].focus();
		        angular.forEach(angular.element(element).children().children().children(), function(value, key){
                    angular.element(value).empty();
                    angular.element(value)[0].style.display="none";
                }); 
		    };
		    
		    var toFocus=0;
		    var toEmpty=0;
		    scope.blurfun=function(){
		        angular.forEach(angular.element(element).children().children().children(), function(value, key){
	                angular.element(value).empty();
	                angular.element(value)[0].style.display="none";
	            });
	            if(toFocus)
	            {
	                toFocus=0;
	                angular.element(element).children().children()[0].focus();
	            }
		    };
		    
		    var focus=-1;
		    var inp=angular.element(element).children().children()[0];
		    inp.addEventListener("keydown", function(e) {
                if (e.keyCode == 40) {
                    focus++;
                    if(noOfSugs>focus)
                    {
                        angular.element(element).children().scope().activesug(focus);
                    }
                    else
                    {
                        focus=0;
                        angular.element(element).children().scope().activesug(focus);
                    }            
                } 
                else if (e.keyCode == 38) {
                    focus--;
                    if(focus>-1)
                    {
                        angular.element(element).children().scope().activesug(focus);
                    }
                    else
                    {
                        focus=noOfSugs-1;
                        angular.element(element).children().scope().activesug(focus);
                    }
                } 
                else if (e.keyCode == 13) {
                    if(focus>-1)
                    {
                        angular.element(element).children().scope().sugclickfun(focus,"focus");
                        angular.element(element).children().children()[0].blur();
                        angular.element(element).children().children()[0].focus();
                    }
                }
            });
            
            scope.activesug=function(focusId){
                angular.forEach(matchingSugDivs, function(value, key){
	                angular.element(value).removeClass("qb-autocomplete-suggestion-active");
	            });
                angular.element(matchingSugDivs[focusId]).addClass("qb-autocomplete-suggestion-active");
            };
		    
		},
		template: function(element,attr){ 
		    return"<div class=\"qb-auto-complete\">"+ 
		        "<input type=\"text\" class=\"qb-auto-complete-input\" ng-model=\"qbModel\" ng-blur=\"blurfun()\">"+
    		    "<div class=\"qb-auto-complete-list\" ng-if=\"listloadfun\" ng-init=\"listloadfun()\" >"+
    		        "<div ng-mousedown=\"sugclickfun(sugid)\" class=\"qb-auto-complete-suggestion\" ng-repeat=\"sugid in sugidies\" ng-init=\"sugloadfun(sugid)\" ></div>"+
    		    "</div>"+
    		    "</div>";
		}
	}
}

myApp.directive('qbRow',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    
		    var win = angular.element(window);
		    win.bind("resize",function(){
		        if(attr.responsive)
		        {
		            if(window.innerWidth>600)
		            {
		                var i=0;
		                angular.forEach(cellEles, function(vCell, key){
        	                angular.element(vCell).css("display","table-cell");
        	                angular.element(vCell).css("width",cellElesWidth[i]);
        	                i++;
        		        });
		            }
		            else
		            {
		                angular.forEach(cellEles, function(vCell, key){
        	                angular.element(vCell).css("display","block");
        	                angular.element(vCell).css("width","100%");
        		        }); 
		            }
		        }
		    });
		    
		    var rowEle;
		    var cellEles;
		    var cellElesWidth=[];
		    scope.rowloadfun=function(){
		        rowEle=angular.element(element).children().children();
		        angular.element(rowEle).append(transclude());
		        cellEles=angular.element(rowEle).children();
		        var numOfCells=cellEles.length;
		        var i=0;
		        angular.forEach(cellEles, function(vCell, key){
	                angular.element(vCell).addClass("qb-cell");
	                cellElesWidth[i]=angular.element(vCell).attr("qb-cell-width");
	                i++;
		        }); 
		        if(window.innerWidth>600)
	            {
	                var j=0;
	                angular.forEach(cellEles, function(vCell, key){
    	                angular.element(vCell).css("float","none");
    	                angular.element(vCell).css("display","table-cell");
    	                angular.element(vCell).css("width",cellElesWidth[j]);
    	                j++;
    		        });
	            }
	            else
	            {
	                angular.forEach(cellEles, function(vCell, key){
    	                angular.element(vCell).css("display","block");
    	                angular.element(vCell).css("width","100%");
    		        });
	            }
		    };
		},
		template: function(element,attr){ 
		    return  "<div class=\"qb-table\" style=\"display:table;table-layout:fixed\">"+
		                "<div class=\"qb-row\" style=\"display:table-row\" ng-if=\"rowloadfun\" ng-init=\"rowloadfun()\"></div>"+
		            "</div>";
		}
	}
}]);

myApp.directive('qbValid',['qbBasics', function(qbBasics) {
    return {
		scope: {
		    qbModel:"="
		},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    var cont="agrawal.ayush2500";
		    scope.blurfun=function(){
		        if(cont===scope.qbModel)
		        {
		            angular.element(angular.element(element).children()[1]).addClass("qb-tab-heading-active");
		        }
		    };
		},
		template: function(element,attr){ 
		    return "<div>"+
		                "<input ng-model=\"qbModel\" ng-blur=\"blurfun()\">"+
		           "</div>"+
		           "<div> already there</div>";
		}
	}
}]);

//qb form
myApp.directive('qbForm',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		},
		template: function(element,attr){ 
		    return  "<div class=\"qb-form\">"+
                    "</div>";
		}
	}
}]);
myApp.directive('qbInput',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		},
		template: function(element,attr){ 
		    return  "<div class=\"qb-input\">"+
                    "</div>";
		}
	}
}]);
myApp.directive('qbAlert',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    
		    scope.loadfun=function(){
		        //insert before
		        if(attr.qbIcon)
		        {
		            var iconClass=qbBasics.classCons(attr.qbIcon);
		            angular.element(element).children().children().addClass(iconClass);
		        }
		        else
		        {
		            angular.element(element).children().children().addClass("fa fa-close")
		        }
		        
		        angular.element(element).children().children()[0].addEventListener("click",function(event){
		            angular.element(element).children()[0].style.display="none";
		        });
		        angular.element(element).children().prepend(transclude());
		        var qbAlertName=angular.element("<strong>"+attr.qbName+"</strong>");
		        angular.element(element).children().prepend(qbAlertName);
		    };
		    
		},
		template: function(element,attr){ 
		    return  "<div class=\"qb-alert\"  ng-if=\"loadfun\" ng-init=\"loadfun()\" >"+
                        "<i class=\"qb-alert-icon\"></i>"+
                    "</div>";
		}
	}
}]);

//qb align last seen on 28-04-2019
myApp.directive('qbContentAlign',['qbBasics', function(qbBasics) {
    return {
		restrict: 'A',
		link: function(scope, element, attr, ctrl, transclude){
		    var horizontalAlign="";
		    var verticalAlign="";
		    var widthType="";
		    var contentsTotalWidth=0;
		    var contents=angular.element(element).children();
		    angular.forEach(contents, function(vCont, kCont){
                var thisWidth=parseFloat(window.getComputedStyle(angular.element(vCont)[0], null).getPropertyValue('width'));
                contentsTotalWidth=contentsTotalWidth+thisWidth;
            });
		    
		    if(!(qbBasics.isQbType(angular.element(element))))
		    {
		        var alignValues=attr.qbContentAlign.split(";");
		        if(contents)
		        {
    		        angular.forEach(alignValues, function(value, key){
    		            var alignValue=""; 
    		            alignValue=value.split(":");
    		            if((alignValue[0])=="vertical")
    		            {
    		                if(((alignValue[1])=="top")||((alignValue[1])=="centre")||((alignValue[1])=="bottom"))
    		                {
    		                    verticalAlign=alignValue[1];
    		                }
    		            }
    		            else if((alignValue[0])=="horizontal")
    		            {
    		                if(((alignValue[1])=="left")||((alignValue[1])=="middle")||((alignValue[1])=="right"))
    		                {
    		                    horizontalAlign=alignValue[1];
    		                }
    		            }
    		            else if((alignValue[0])=="width-type")
    		            {
    		                if(((alignValue[1])=="responsive")||((alignValue[1])=="static"))
    		                {
    		                    widthType=alignValue[1];
    		                }
    		            }
    		        });
    		        qbBasics.contentsAlign(angular.element(element),horizontalAlign,verticalAlign,widthType,contentsTotalWidth);
		        }
		    }
		    
		    var win = angular.element(window);
		    win.bind("resize",function(){
		        qbBasics.contentsAlignResize(angular.element(element),horizontalAlign,verticalAlign,widthType,contentsTotalWidth);
		    });
	
		}
	}
}]);

myApp.directive('qbShowMenus',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
	        if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
	        
	        var trans=angular.element("<div></div>");
	        trans.append(transclude());
		    
		    scope.qbMenusOpenFun=function(){
		        angular.element(angular.element(element).children().children()[1]).addClass("qb-menus-open");
		        angular.element(angular.element(element).children().children()[1]).removeClass("qb-menus-close");
		        var qbMenusIcons=qbBasics.findChildren(angular.element(element),"qb-menus-icon");
		        angular.forEach(qbMenusIcons, function(value, key){
		            if((angular.element(value).attr("icon-type"))==="open")
		            {
		                angular.element(value).children().addClass("qb-menus-icon-close");
		                angular.element(value).children().removeClass("qb-menus-icon-open");
		            }
		            else if((angular.element(value).attr("icon-type"))==="close")
		            {
		                angular.element(value).children().addClass("qb-menus-icon-open");
		                angular.element(value).children().removeClass("qb-menus-icon-close");
		            }
                });
		    };
		    
		   scope.qbMenusCloseFun=function(){
		        angular.element(angular.element(element).children().children()[1]).addClass("qb-menus-close");
		        angular.element(angular.element(element).children().children()[1]).removeClass("qb-menus-open");
		        var qbMenusIcons=qbBasics.findChildren(angular.element(element),"qb-menus-icon");
		        angular.forEach(qbMenusIcons, function(value, key){
		            if((angular.element(value).attr("icon-type"))==="open")
		            {
		                angular.element(value).children().addClass("qb-menus-icon-open");
		                angular.element(value).children().removeClass("qb-menus-icon-close");
		            }
		            else if((angular.element(value).attr("icon-type"))==="close")
		            {
		                angular.element(value).children().addClass("qb-menus-icon-close");
		                angular.element(value).children().removeClass("qb-menus-icon-open");
		            }
                });
		    };
		    
		    scope.qbMenusMobShowFun=function(){
		        angular.element(element).children().children()[0].style.display="block";
		        angular.element(angular.element(element).children().children()[1]).addClass("qb-menus-close");
		        angular.element(angular.element(element).children().children()[1]).removeClass("qb-menus-open");
		        
		    };
		    
		    scope.qbMenusDeskShowFun=function(){
		        angular.element(element).children().children()[0].style.display="none";
		        angular.element(angular.element(element).children().children()[1]).addClass("qb-menus-open");
		        angular.element(angular.element(element).children().children()[1]).removeClass("qb-menus-close");
		    };
		    
		    
		    var isResponsive=attr.responsive;
		    var win = angular.element(window);
		    win.bind('resize', function () {
		        if(isResponsive)
		        {
                    var scWidth= window.innerWidth;
                    if(scWidth>600)
                    {
                        angular.element(element).children().scope().qbMenusDeskShowFun();
                    }
                    else
                    {
                        angular.element(element).children().scope().qbMenusMobShowFun();
                        angular.element(element).children().scope().qbMenusCloseFun();
                    }
		        }
            });
		    
		    scope.qbShowTopMenusLoadFun=function(){   
    	        if(window.innerWidth<600)
    	        {
    	            angular.element(element).children().scope().qbMenusMobShowFun();
    	        }
    	        else
    	        {
    	            angular.element(element).children().scope().qbMenusDeskShowFun();
    	        }
    	        
    	        var qbMenuHeight=parseFloat(window.getComputedStyle(angular.element(angular.element(element).children().children()[1]).children()[0], null).getPropertyValue('height'));
    	        /*var qbSubMenusAll=angular.element(element)[0].querySelectorAll(".qb-sub-sub-menus-top-type");
		        angular.forEach(qbSubMenusAll, function(value, key){
		            var qbMenuId=angular.element(value).parent().attr("qb-menu-in-sub-menus-id");
		           angular.element(value).css("top",(qbMenuHeight*qbMenuId)+"px");
                });*/
                
                var qbSubMenusAll=angular.element(element)[0].querySelectorAll(".qb-sub-menus");
		        angular.forEach(qbSubMenusAll, function(value, key){
		            if(angular.element(value).parent().hasClass("qb-menu-in-sub-menus"))
		            {
		                angular.element(value).addClass("qb-sub-sub-menus-top-type");
		                var qbMenuId=angular.element(value).parent().attr("qb-menu-in-sub-menus-id");
    		            angular.element(value).css("top",(qbMenuHeight*qbMenuId)+"px");
		            }
		            /*else if(angular.element(value).parent().hasClass("qb-menu-in-top-menus"))
		            {
		                angular.element(value).addClass("qb-top-sub-menus");
		            }*/
                });
                
		    };
		    
		    scope.qbShowLeftMenusLoadFun=function(){
    	        if(window.innerWidth<600)
    	        {
    	            angular.element(element).children().scope().qbMenusMobShowFun();
    	        }
    	        else
    	        {
    	            angular.element(element).children().scope().qbMenusDeskShowFun();
    	        }
    	        
		        var qbSubMenusAll=angular.element(element)[0].querySelectorAll(".qb-sub-menus");
		        angular.forEach(qbSubMenusAll, function(value, key){
		            if(angular.element(value).parent().hasClass("qb-menu-in-sub-menus"))
		            {
		                angular.element(value).addClass("qb-sub-sub-menus-left-type");
		            }
		            else if(angular.element(value).parent().hasClass("qb-menu-in-left-menus"))
		            {
		                angular.element(value).addClass("qb-left-sub-menus");
		            }
		        });
		    };
		    
		    
		    scope.qbShowIconMenusLoadFun=function(){
    	        angular.element(element).children().scope().qbMenusMobShowFun();
    	        
		        var qbSubMenusAll=angular.element(element)[0].querySelectorAll(".qb-sub-menus");
		        angular.forEach(qbSubMenusAll, function(value, key){
		            if(angular.element(value).parent().hasClass("qb-menu-in-sub-menus"))
		            {
		                angular.element(value).addClass("qb-sub-sub-menus-icon-type");
		            }
		            else if(angular.element(value).parent().hasClass("qb-menu-in-icon-menus"))
		            {
		                angular.element(value).addClass("qb-icon-sub-menus");
		            }
		        });
		        isResponsive=false;
		    };
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-show-menus\">"+
		                "<div class=\"qb-show-menus-icon-div\" ng-click=\"qbShowMenusClickFun()\" ng-transclude> </div>"+
		           "</div>"
		}   
    }
}]);

myApp.directive('qbMenusHeading',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-menus-heading\" ng-transclude>"+
		           "</div>"
		}   
    }
}]);

myApp.directive('qbMenusIcon',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    
		    if((attr.iconType)==="open")
		    {
		        angular.element(element).children().addClass("qb-menus-icon-open");
		    }
		    else if((attr.iconType)==="close")
		    {
		        angular.element(element).children().addClass("qb-menus-icon-close");
		    }
		    
		    scope.qbMenusIconClickFun=function(){
		        var qbShowMenus=qbBasics.findParent(angular.element(element),"qb-show-menus");
		        if((attr.iconType)==="open")
    		    {
    		        angular.element(qbShowMenus).children().scope().qbMenusOpenFun();
    		    }
    		    else if((attr.iconType)==="close")
    		    {
    		        angular.element(qbShowMenus).children().scope().qbMenusCloseFun();
    		    }   
		    };
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-menus-icon\" ng-click=\"qbMenusIconClickFun()\" ng-transclude>"+
		           "</div>"
		}   
    }
}]);
myApp.directive('qbMenus',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    
		    scope.qbMenusLoadFun=function(){
		        if((attr.qbMenuType)==="top")
		        {
		            angular.element(element).children().scope().qbTopMenusLoadFun();
		        }
		        else if((attr.qbMenuType)==="left")
		        {
		            angular.element(element).children().scope().qbLeftMenusLoadFun();
		        }
		        else if((attr.qbMenuType)==="icon")
		        {
		            angular.element(element).children().scope().qbIconMenusLoadFun();
		        }
		    };
		    
		    scope.qbIconMenusLoadFun=function(){
		        var qbMainMenuDiv=angular.element("<div class=\"qb-menus qb-icon-menus\" style=\"overflow:hidden\"></div>");
		        if(attr.classes)
		        {
		            qbMainMenuDiv.addClass(qbBasics.classCons(attr.classes));
		        }
		        angular.element(element).children().empty();
		        angular.element(element).children().append(transclude());
		        var qbMenuContents=angular.element(element).children().children();
		        var i=0;
		        angular.forEach(qbMenuContents, function(value, key){
                    if((angular.element(value)[0].nodeName)==="QB-MENU")
                    {
                        var qbMenuEle=angular.element(value).children().scope().qbMenuLoadFun();
                        if(qbMenuEle)
                        {
                            qbMainMenuDiv.append(angular.element(qbMenuEle).html());
                        }
                        angular.element(value).children().attr("qb-menu-id","qb-menu-"+i);
                        i++;
                    }
                });
                var qbMenuInLeftMenusIdies=0;
                var qbMenuInLeftMenus=angular.element(qbMainMenuDiv).children();
                angular.forEach(qbMenuInLeftMenus, function(value, key){
                    if(angular.element(value).hasClass("qb-menu"))
                    {
                        angular.element(value).addClass("qb-menu-in-icon-menus");
                        angular.element(value).attr("qb-menu-in-icon-menus-id",qbMenuInLeftMenusIdies);
                        qbMenuInLeftMenusIdies++;
                    }
                });
                
		        angular.element(element).children().empty();
		        var qbShowMenus=document.querySelectorAll("qb-show-menus");
		        angular.forEach(qbShowMenus, function(value, key){
                    if((angular.element(value).attr("qb-menus-id"))===(angular.element(element).attr("qb-menus-id")))
                    {
		                angular.element(value).children().append(angular.element(qbMainMenuDiv));
		                angular.element(value).children().scope().qbShowIconMenusLoadFun();
                    }
                });
		        
		    };
		    
		    scope.qbLeftMenusLoadFun=function(){
		        var qbMainMenuDiv=angular.element("<div class=\"qb-menus qb-left-menus\" style=\"overflow:hidden\"></div>");
		        if(attr.classes)
		        {
		            qbMainMenuDiv.addClass(qbBasics.classCons(attr.classes));
		        }
		        angular.element(element).children().empty();
		        angular.element(element).children().append(transclude());
		        var qbMenuContents=angular.element(element).children().children();
		        var i=0;
		        angular.forEach(qbMenuContents, function(value, key){
                    if((angular.element(value)[0].nodeName)==="QB-MENU")
                    {
                        var qbMenuEle=angular.element(value).children().scope().qbMenuLoadFun();
                        if(qbMenuEle)
                        {
                            qbMainMenuDiv.append(angular.element(qbMenuEle).html());
                        }
                        angular.element(value).children().attr("qb-menu-id","qb-menu-"+i);
                        i++;
                    }
                });
                var qbMenuInLeftMenusIdies=0;
                var qbMenuInLeftMenus=angular.element(qbMainMenuDiv).children();
                angular.forEach(qbMenuInLeftMenus, function(value, key){
                    if(angular.element(value).hasClass("qb-menu"))
                    {
                        angular.element(value).addClass("qb-menu-in-left-menus");
                        angular.element(value).attr("qb-menu-in-left-menus-id",qbMenuInLeftMenusIdies);
                        qbMenuInLeftMenusIdies++;
                    }
                });
                
		        angular.element(element).children().empty();
		        var qbShowMenus=document.querySelectorAll("qb-show-menus");
		        angular.forEach(qbShowMenus, function(value, key){
                    if((angular.element(value).attr("qb-menus-id"))===(angular.element(element).attr("qb-menus-id")))
                    {
		                angular.element(value).children().append(angular.element(qbMainMenuDiv));
		                angular.element(value).children().scope().qbShowLeftMenusLoadFun();
                    }
                });
		        
		    };
		    
		    scope.qbTopMenusLoadFun=function(){
		        var qbMainMenuDiv=angular.element("<div class=\"qb-menus qb-top-menus\" style=\"overflow:hidden\"></div>");
		        if(attr.classes)
		        {
		            qbMainMenuDiv.addClass(qbBasics.classCons(attr.classes));
		        }
		        angular.element(element).children().empty();
		        angular.element(element).children().append(transclude());
		        var qbMenuContents=angular.element(element).children().children();
		        var i=0;
		        angular.forEach(qbMenuContents, function(value, key){
                    if((angular.element(value)[0].nodeName)==="QB-MENU")
                    {
                        var qbMenuEle=angular.element(value).children().scope().qbMenuLoadFun();
                        if(qbMenuEle)
                        {
                            qbMainMenuDiv.append(angular.element(qbMenuEle).html());
                        }
                        angular.element(value).children().attr("qb-menu-id","qb-menu-"+i);
                        i++;
                    }
                });
                var screenWidth=window.innerWidth;
                var qbMenuInTopMenuWidth;
                if(screenWidth>600)
                {
                    qbMenuInTopMenuWidth=(screenWidth/i);
                }
                else
                {
                    qbMenuInTopMenuWidth=screenWidth;
                }
                var qbMenuInTopMenusIdies=0;
                var qbMenuInSubMenus=angular.element(qbMainMenuDiv).children();
                angular.forEach(qbMenuInSubMenus, function(value, key){
                    if(angular.element(value).hasClass("qb-menu"))
                    {
                        angular.element(value).addClass("qb-menu-in-top-menus");
                        angular.element(value).css("width",qbMenuInTopMenuWidth+"px");
                        angular.element(value).attr("qb-menu-in-top-menus-id",qbMenuInTopMenusIdies);
                        qbMenuInTopMenusIdies++;
                    }
                });
                
                var qbTopSubMenus=angular.element(qbMainMenuDiv).children().children();
                angular.forEach(qbTopSubMenus, function(value, key){
		            if(angular.element(value).parent().hasClass("qb-menu-in-top-menus"))
		            {
		                if(angular.element(value).hasClass("qb-sub-menus"))
		                {
		                    angular.element(value).addClass("qb-top-sub-menus");
		                }
		            }
		        });
		        
		        var qbShowMenus=document.querySelectorAll("qb-show-menus");
		        angular.forEach(qbShowMenus, function(value, key){
                    if((angular.element(value).attr("qb-menus-id"))===(angular.element(element).attr("qb-menus-id")))
                    {
		                angular.element(value).children().append(angular.element(qbMainMenuDiv));
		                angular.element(value).children().scope().qbShowTopMenusLoadFun();
                    }
                });
                angular.element(element).empty();
            };
		    
		    scope.qbSubMenusLoadFun=function(){
		        angular.element(element).children().empty();
		        angular.element(element).children().append(transclude());
		        var qbMenuContents=angular.element(element).children().children();
		        var i=0;
		        var qbSubMenusEle=angular.element("<div class=\"qbsubmenus\"><div class=\"qb-sub-menus\"></div></div>");
		        if(attr.classes)
		        {
		            qbSubMenusEle.children().addClass(qbBasics.classCons(attr.classes));
		        }
		        angular.forEach(qbMenuContents, function(value, key){
                    if((angular.element(value)[0].nodeName)==="QB-MENU")
                    {
                        var qbMenuRet=angular.element(value).children().scope().qbMenuLoadFun();
                        qbSubMenusEle.children().append(qbMenuRet.html());
                        angular.element(value).children().attr("qb-menu-id","qb-menu-"+i);
                        i++;
                    }
                });
                
                var qbMenuInSubMenusIdies=0;
                var qbMenuInSubMenus=angular.element(qbSubMenusEle).children().children();
                angular.forEach(qbMenuInSubMenus, function(value, key){
                    if(angular.element(value).hasClass("qb-menu"))
                    {
                        angular.element(value).addClass("qb-menu-in-sub-menus");
                        angular.element(value).attr("qb-menu-in-sub-menus-id",qbMenuInSubMenusIdies);
                        qbMenuInSubMenusIdies++;
                    }
                });
                
                var qbSubSubMenus=angular.element(qbSubMenusEle).children().children().children();
                angular.forEach(qbSubSubMenus, function(value, key){
                    if(angular.element(value).parent().hasClass("qb-menu-in-sub-menus"))
		            {
		                if(!(angular.element(value).hasClass("qb-menu-heading")))
		                {
		                    angular.element(value).addClass("qb-sub-sub-menus");
		                }
		            }
		        });
		        
		        return qbSubMenusEle;
    	    };
    	    
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-menus\" style=\"display:none\">"+
		                "<div ng-if=\"qbMenusLoadFun\" ng-init=\"qbMenusLoadFun()\"></div>"+
		           "</div>";
		}
	}
}]);

myApp.directive('qbMenu',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    
		    scope.qbMenuLoadFun=function(){
		        var qbDiv=angular.element("<div></div>");
		        qbDiv.append(transclude());
		        var qbSubMenus=qbDiv.children();
		        var qbSubMenusExist=false;
		        angular.forEach(qbSubMenus, function(value, key){
	                if((angular.element(value)[0].nodeName)==="QB-MENUS")
	                {
	                    qbSubMenusExist=true;
	                }
	            }); 
	            if(qbSubMenusExist)
	            {
	                var qbSubMenusEle=angular.element("<div class=\"qbsubmenus\"></div>");
	                angular.forEach(qbSubMenus, function(value, key){
    	                if((angular.element(value)[0].nodeName)==="QB-MENUS")
    	                {
    	                    if((angular.element(value).attr("qb-menu-type"))==="sub")
    	                    {
    	                        var qbSubMenusRet=angular.element(value).children().scope().qbSubMenusLoadFun();
    	                        qbSubMenusEle.append(qbSubMenusRet.html());
    	                    }
    	                }
    	            }); 
    	            
    	            var qbMenuDiv=angular.element("<div></div>");
    	            var qbMenuHeading=angular.element(element).children().children();
    	            var qbSubMenusDiv=qbBasics.findChildren(angular.element(qbDiv),"QB-MENUS");
    	            qbDiv.children().remove();
    	            qbMenuHeading.append(qbDiv.html());
    	            qbMenuDiv.append(qbSubMenusDiv);
    	            angular.element(element).children().append(qbMenuDiv.html());
    	            
                    var qbMenuEle=angular.element("<div class=\"\"><div class=\"qb-menu\"></div></div>");
                    qbMenuEle.children().append(qbMenuHeading);
                    qbMenuEle.children().append(qbSubMenusEle.html());
                    if(attr.classes)
                    {
                        qbMenuEle.children().addClass(qbBasics.classCons(attr.classes));
                    }
                    return qbMenuEle;
	            }
	            else
	            {
	                angular.element(element).children().empty();
	                var qbAnchor=angular.element("<div class=\"qb-menu-heading\"><a class=\""+attr.qbAnchorClass+"\" href=\""+attr.qbLink+"\"></a></div>");
                    qbAnchor.children().append(qbDiv.html());
                    angular.element(element).children().append(qbAnchor);
                    var qbMenuEle=angular.element(element);
                    if(attr.classes)
                    {
                        qbMenuEle.children().addClass(qbBasics.classCons(attr.classes));
                    }
                    return qbMenuEle;
	            }
		    };
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-menu\">"+
		                "<div class=\"qb-menu-heading\"></div>"+
		           "</div>";
		}
	}
}]);

myApp.directive('qbModal',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    scope.qbModalLoadFun=function(){
		        var qbModalEle=angular.element("<div></div>");
		        qbModalEle.append(transclude());
		        var qbModalEleConts=qbModalEle.children();
		        angular.forEach(qbModalEleConts, function(value, key){
		            if((angular.element(value)[0].nodeName)==="QB-MODAL-CLOSE-BUTTON")
		            {
		                var qbModalCloseButton=angular.element("<button class=\"qb-modal-close-button\"></button>");
		                qbModalCloseButton.append(angular.element(value).html());
		                qbModalCloseButton.bind("click",function(event){
		                    angular.element(element).children().scope().qbModalCloseFun();
		                });
		                var qbModalChildren=angular.element(element).children().children();
		                angular.forEach(qbModalChildren, function(vModal, key){
		                    if(angular.element(vModal).hasClass("qb-modal-content"))
		                    {
		                        angular.element(vModal).append(qbModalCloseButton);
		                    }
		                });
		            }
		            else if((angular.element(value)[0].nodeName)==="QB-MODAL-CONTENT")
		            {
		                var qbModalChildren=angular.element(element).children().children();
		                angular.forEach(qbModalChildren, function(vModal, key){
		                    if(angular.element(vModal).hasClass("qb-modal-content"))
		                    {
		                        angular.element(vModal).append(angular.element(value).html());
		                    }
		                });
		            }
		            else if((angular.element(value)[0].nodeName)==="QB-MODAL-OPEN-BUTTON")
		            {
		                var qbModalOpenButton=angular.element("<button class=\"qb-modal-open-button\"></button>");
		                qbModalOpenButton.append(angular.element(value).html());
		                qbModalOpenButton.bind("click",function(event){
		                    angular.element(element).children().scope().qbModalOpenFun();
		                });
		                angular.element(angular.element(element).children()).prepend(qbModalOpenButton);
		            } 
		        });
		    };
		    
		    scope.qbModalOpenFun=function(){
		        var qbModalChildren=angular.element(element).children().children();
		        angular.forEach(qbModalChildren, function(vModal, key){
                    if(angular.element(vModal).hasClass("qb-modal-content"))
                    {
                        angular.element(vModal).addClass("qb-modal-content-open");
                        angular.element(vModal).removeClass("qb-modal-content-close");
                    }
                });
		    };
		    
		    scope.qbModalCloseFun=function(){
		        var qbModalChildren=angular.element(element).children().children();
		        angular.forEach(qbModalChildren, function(vModal, key){
                    if(angular.element(vModal).hasClass("qb-modal-content"))
                    {
                        angular.element(vModal).addClass("qb-modal-content-close");
                        angular.element(vModal).removeClass("qb-modal-content-open");
                    }
                });
		    };
		},
		template: function(element,attr){
		    return "<div class=\"qb-modal\" ng-if=\"qbModalLoadFun\" ng-init=\"qbModalLoadFun()\">"+
		                "<div class=\"qb-modal-content qb-modal-content-close\">"+
		                "</div>"+
		           "</div>"
		}
    }
}]);

myApp.directive('qbBar',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    
		    scope.qbBarLoadFun=function(){
    		    if(attr.qbBarType)
    		    {
    		        if((attr.qbBarType)==="menu")
    		        {
    		            angular.element(element).children().addClass("qb-menu-bar");
    		            angular.element(element).children().scope().qbBarOpenFun();
    		        }
    		        else if((attr.qbBarType)==="search")
    		        {
    		            angular.element(element).children().addClass("qb-search-bar");
    		            angular.element(element).children().scope().qbBarCloseFun();
    		        }
    		    }  
		    };
		    
		    scope.qbBarOpenFun=function(){
		        angular.element(element).children().addClass(qbBasics.classCons(attr.qbOpenClass));
		        angular.element(element).children().removeClass(qbBasics.classCons(attr.qbCloseClass));
		    };
		    
		    scope.qbBarCloseFun=function(){
		        angular.element(element).children().addClass(qbBasics.classCons(attr.qbCloseClass));
		        angular.element(element).children().removeClass(qbBasics.classCons(attr.qbOpenClass));
		    };
		    
		    
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-bar\" ng-if=\"qbBarLoadFun\" ng-init=\"qbBarLoadFun()\" ng-transclude>"+
		           "</div>"
		}   
    }
}]);

myApp.directive('qbIcon',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    scope.qbIconClickFun=function(){
		        var qbBars=document.querySelectorAll("qb-bar");
		        if((attr.qbIconType)==="search")
		        {
		            angular.forEach(qbBars, function(qbBar, key){
		                if(angular.element(qbBar).attr("qb-bar-type")==="menu")
		                {
    		                if((attr.qbIconId)==(angular.element(qbBar).attr("qb-bar-id")))
    		                {
    		                    angular.element(qbBar).children().scope().qbBarCloseFun();
    		                }
		                }
		                else if(angular.element(qbBar).attr("qb-bar-type")==="search")
		                {
    		                if((attr.qbTargetId)==(angular.element(qbBar).attr("qb-bar-id")))
    		                {
    		                    angular.element(qbBar).children().scope().qbBarOpenFun();
    		                }
		                }
		            });
		        }
		        else if((attr.qbIconType)==="back")
		        {
		            angular.forEach(qbBars, function(qbBar, key){
		                if(angular.element(qbBar).attr("qb-bar-type")==="menu")
		                {
    		                if((attr.qbTargetId)==(angular.element(qbBar).attr("qb-bar-id")))
    		                {
    		                    angular.element(qbBar).children().scope().qbBarOpenFun();
    		                }
		                }
		                else if(angular.element(qbBar).attr("qb-bar-type")==="search")
		                {
    		                if((attr.qbIconId)==(angular.element(qbBar).attr("qb-bar-id")))
    		                {
    		                    angular.element(qbBar).children().scope().qbBarCloseFun();
    		                }
		                }
		            });
		        }
		    };
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-icon\" ng-click=\"qbIconClickFun()\" ng-transclude>"+
		           "</div>"
		}   
    }
}]);

myApp.directive('qbAvatar',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
		   angular.element(element).children().addClass(attr.qbAvatarClass);
		   angular.element(element).children().children().addClass(attr.qbImageClass);
		},
		template: function(element,attr){ 
		    return "<div style=\"overflow:hidden\">"+
		                "<img src=\""+attr.qbSrc+"\" class=\"qb-avatar-image\" height=\""+attr.qbHeight+"\" width=\""+attr.qbWidth+"\" style=\"object-fit:cover\">"+
		           "</div>";
		}
	}
}]);