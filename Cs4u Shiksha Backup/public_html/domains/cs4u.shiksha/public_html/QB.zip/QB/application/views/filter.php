<html>
    <head>
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
		<script src="../../public/js/cube code.js"></script>
		<script src="../../public/js/cube fabric.js"></script>
    </head>
    <body>
        <div ng-app="myApp" ng-controller="myCtrl">
            <row color="red" margin="10" border="10,solid" > 
			    Man
		    </row>
    </body>
</html>