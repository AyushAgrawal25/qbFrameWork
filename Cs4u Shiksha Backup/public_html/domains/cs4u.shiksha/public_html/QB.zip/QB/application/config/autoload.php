<?php
	$autoload['classes'] = array('database','mailer','file');
	$autoload['functions'] = array('form','url','http');
	$autoload['model'] = array('authentication_model','test_model','registration_model','feed_model');

