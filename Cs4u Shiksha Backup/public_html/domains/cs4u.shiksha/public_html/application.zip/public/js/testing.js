var myApp=angular.module('myApp',['qbLayout','qbDataBase','qbWidgets','qbForm']);

myApp.controller('myCtrl', function($scope){});