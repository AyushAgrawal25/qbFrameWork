var myApp = angular.module("myApp", ['ngMessages']);
myApp.controller('myCtrl', function($scope) {
    $scope.data1=["ayush","ishan","aman"];
    $scope.datas;
    $scope.data2=["aman","raj","sanskar"];
	$scope.functest=function()
	{
		alert($scope.firstname);
	}
	$scope.combo=function()
	{
	    return $scope.datas
	}
	$scope.myClick=function(data)
	{
	   $scope.value=data;
	}
	$scope.element;
	
});

myApp.service('qbBasics',function(){
    this.classCons= function (classes) {
        var allClass=classes.split(',');
        var classL="";
        var k=0;
        angular.forEach(allClass, function(value, key){
            if(!(classL))
                classL=allClass[k];
            else
                classL=classL+" "+allClass[k];
            k++;
        });
        return classL;
    }
    this.findParent=function(pElement,pName){
        var par=pElement.parent();
        var con=true;
        var reqElement;
        while(con)
        {
            if((par[0].nodeName)===pName)
            {
                reqElement=par;
                con=false;
            }
            else if((par[0].nodeName)==="BODY")
            {
                con=false;
                reqElement=undefined;
            }
            else
                par=par.parent();
        }
        if(reqElement===undefined)
            alert("Undefined Parent Name");
        return reqElement;
    }
    this.findChildren=function(cElement,cName){
        var child=cElement.children();
        var reqChildren=[];
        var con=true;
        var found=false;
        while(con)
        {
            if(typeof child !== 'undefined' && child.length > 0)
            {
                var i=0;
                var j=0;
                angular.forEach(child, function(value, key){
                    if((angular.element(value)[0].nodeName)===(cName.toUpperCase()))
                    {
                        reqChildren[i]=child[j];
                        i++;
                        found=true;
                    }
                    j++;
                });
                if(found)
                {
                    con=false;
                }
                else
                {
                    child=child.children();    
                }
            }
            else
            {
                con=false;
                //alert("Undefined Children NodeName");
            }
        }
        return reqChildren;
    }
    this.findElement=function(eName){
        var qbContainer=angular.element(document.querySelector(eName));
        var con=true;
        var found=false;
        var reqElement;
        /*var child=qbContainer.children();
        while(con)
        {
            if(typeof child !== 'undefined' && child.length > 0)
            {
                var i=0;
                angular.forEach(child, function(value, key){
                    if((angular.element(value)[0].nodeName)===(eName.toUpperCase()))
                    {
                       reqElement=child[i];
                        found=true;
                    }
                    i++;
                });
                if(found)
                {
                    con=false;
                }
                else
                {
                    child=child.children();    
                }
            }
            else
            {
                con=false;
                alert("Undefined Element NodeName");
            }
        }*/
        return qbContainer;
    }
    
    this.findQbChildren=function(eObject){
        var child=eObject.children();
        var reqChildren=[];
        var con=true;
        var found=false;
        while(con)
        {
            if(typeof child !== 'undefined' && child.length > 0)
            {
                var i=0;
                var j=0;
                angular.forEach(child, function(value, key){
                    var childName=angular.element(value)[0].nodeName;
                    if(((childName[0])==="Q")&&((childName[1])==="B")&&((childName[2])==="-"))
                    {
                        reqChildren[i]=child[j];
                        i++;
                        found=true;
                    }
                    j++;
                });
                if(found)
                {
                    con=false;
                }
                else
                {
                    child=child.children();    
                }
            }
            else
            {
                con=false;
                //alert("Undefined Children NodeName");
            }
        }
        return reqChildren;
    }
});

//last seen on 22-07-2019
//heading styling
myApp.directive('qbTabs',['qbBasics', function(qbBasics) {
    return {
	    scope: {},
		transclude: true,
		link: function(scope,element,attr){
		    var qbTabs=qbBasics.findChildren(angular.element(element),"QB-TAB");
		    var qbTabHeadings=qbBasics.findChildren(angular.element(element),"QB-TAB-HEADING");
		    var qbTabContents=qbBasics.findChildren(angular.element(element),"QB-TAB-CONTENT");
		    var numOfHeadings=qbTabHeadings.length;
		    scope.qbidies=[];
		    var i=0;
		    angular.forEach(qbTabs, function(value, key){
		        scope.qbidies.push("qb-tab-"+i);
		        angular.element(qbTabs[i]).children().attr("qb-tab-id",scope.qbidies[i]);
		        angular.element(qbTabHeadings[i]).children().attr("qb-tab-id",scope.qbidies[i]);
		        angular.element(qbTabContents[i]).children().attr("qb-tab-id",scope.qbidies[i]);
		        i++;
		    });
		    
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    
            var headingAllign="";
            var headingSizeType="";
            var headingTotalWidth="";
            var headingComputedWidth="";
            var headingGivenWidth="";
            
            var headingPaddingRight="";
            var headingPaddingLeft="";
            var headingMarginRight="";
            var headingMarginLeft="";
            var headingBorderRight="";
            var headingBorderLeft="";
            
            if(attr.qbHeadingsStyle)
		    {
		        var qbHeadStyles=attr.qbHeadingsStyle.split(";");
		        angular.forEach(qbHeadStyles, function(value, key){
		            var qbHeadStyle="";
		            qbHeadStyle=value.split(":");
		            if((qbHeadStyle[0])==="allign")
		            {
		                if((qbHeadStyle[1])==="left")
		                {
		                    headingAllign="left";
		                }
		                else if((qbHeadStyle[1])==="right")
		                {
		                    headingAllign="right";
		                }
		                else if((qbHeadStyle[1])==="centre")
		                {
		                    headingAllign="centre";
		                }
		            }
		            else if((qbHeadStyle[0])==="size")
		            {
		                if((qbHeadStyle[1])==="equal")
		                {
		                    headingSizeType="equal";
		                    //angular.element(element).children().scope().headingSize(headSize,"equal");
		                }
		                else if((qbHeadStyle[1])==="auto")
		                {
		                    headingSizeType="auto";
		                }
		                else if((qbHeadStyle[1])==="fullfill")
		                {
		                    headingSizeType="fullfill";
		                }
		            }
		            else if((qbHeadStyle[0])==="total-width") 
		            {
		                if(qbHeadStyle[1])
		                {
		                    headingTotalWidth=parseFloat(qbHeadStyle[1]);
		                }
		            }
		        });
		        if(headingTotalWidth)
		        {
    	            var headingCont=angular.element(angular.element(element).children().children()[0]);
    	            headingComputedWidth=parseFloat(window.getComputedStyle(headingCont[0], null).getPropertyValue('width'));
    	            headingGivenWidth=headingComputedWidth/100*headingTotalWidth;
    	            
    	            headingPaddingRight=parseFloat(window.getComputedStyle(headingCont[0], null).getPropertyValue('padding-right'));
    	            headingPaddingLeft=parseFloat(window.getComputedStyle(headingCont[0], null).getPropertyValue('padding-left'));
		        }
		        else
		        {
    	            var headingCont=angular.element(angular.element(element).children().children()[0]);
    	            headingComputedWidth=parseFloat(window.getComputedStyle(headingCont[0], null).getPropertyValue('width'));
    	            headingGivenWidth=headingComputedWidth;
    	            
    	            headingPaddingRight=parseFloat(window.getComputedStyle(headingCont[0], null).getPropertyValue('padding-right'));
    	            headingPaddingLeft=parseFloat(window.getComputedStyle(headingCont[0], null).getPropertyValue('padding-left'));
		        }
		    } 
		    
		    
		    var headingSize=0;
		    scope.headingStyle=function(headWidth){
		        //size type
		        if(headingSizeType==="fullfill")
		        {
		            if(headingTotalWidth)
        	        {
        	            var headingWidth=(headingGivenWidth)/(numOfHeadings);
        	            
        	            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		                angular.forEach(headingDivs, function(value, key){
        	                var thisPaddingLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-left'));
        	                var thisPaddingRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-right'));
        	                var thisMarginLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-left'));
        	                var thisMarginRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-right'));
        	                var thisBorderLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-left'));
        	                var thisBorderRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-right'));
        	                
        	                var thisCalculatedWidth=headingWidth-(thisPaddingLeft+thisPaddingRight+thisMarginLeft+thisMarginRight+thisBorderLeft+thisBorderRight);
        	                angular.element(value).css("width",thisCalculatedWidth+"px");
        	            });
        	        }
        	        else
        	        {
        	            var headingWidth=(headingGivenWidth)/(numOfHeadings);
        	            
        	            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		                angular.forEach(headingDivs, function(value, key){
        	                var thisPaddingLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-left'));
        	                var thisPaddingRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-right'));
        	                var thisMarginLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-left'));
        	                var thisMarginRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-right'));
        	                var thisBorderLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-left'));
        	                var thisBorderRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-right'));
        	                
        	                var thisCalculatedWidth=headingWidth-(thisPaddingLeft+thisPaddingRight+thisMarginLeft+thisMarginRight+thisBorderLeft+thisBorderRight);
        	                angular.element(value).css("width",thisCalculatedWidth+"px");
        	            });
        	        }
		        }
		        else if(headingSizeType==="equal")
		        {
		            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		            if(headWidth>headingSize)
    		        {
    		            headingSize=headWidth;
    		        }
    		        angular.forEach(headingDivs, function(value, key){
    	                //all values of padding margin border
    	                var thisPaddingLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-left'));
    	                var thisPaddingRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-right'));
    	                var thisMarginLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-left'));
    	                var thisMarginRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-right'));
    	                var thisBorderLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-left'));
    	                var thisBorderRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-right'));
    	                
    	                var thisTotalWidth=thisPaddingLeft+thisPaddingRight+thisMarginLeft+thisMarginRight+thisBorderLeft+thisBorderRight+headingSize;
    	                angular.element(value).css("width",thisTotalWidth+"px");
    	            });   
		        }
		        else if(headingSizeType==="auto")
		        {
		            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		            angular.forEach(headingDivs, function(value, key){
		                angular.element(value).css("width","auto");
    	            });
		        }
		        
		        //total width
		        if(headingTotalWidth)
		        {
		            
		        }
		        
		        // allignment
		        if(headingAllign==="left")
		        {
		            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		            angular.forEach(headingDivs, function(value, key){
		                angular.element(value).css("float","left");
    	            });
    	            var paddingRight=(headingComputedWidth-headingGivenWidth)+headingPaddingRight;
    	            angular.element(angular.element(element).children().children()[0]).css("padding-right",paddingRight+"px");
    	            
    	        }
		        else if(headingAllign==="right")
		        {
		            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		            angular.forEach(headingDivs, function(value, key){
		                angular.element(value).css("float","left");
    	            });
    	            var paddingLeft=(headingComputedWidth-headingGivenWidth)+headingPaddingLeft;
    	            angular.element(angular.element(element).children().children()[0]).css("padding-left",paddingLeft+"px");
		        }
		        else if(headingAllign==="centre")
		        {
		            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		            angular.forEach(headingDivs, function(value, key){
		                angular.element(value).css("float","left");
    	            });
    	            var paddingRight=((headingComputedWidth-headingGivenWidth)/2)+headingPaddingRight;
    	            var paddingLeft=((headingComputedWidth-headingGivenWidth)/2)+headingPaddingLeft;
    	            angular.element(angular.element(element).children().children()[0]).css("padding-right",paddingRight+"px");
    	            angular.element(angular.element(element).children().children()[0]).css("padding-left",paddingLeft+"px");
		        }
		    };
		    
		    scope.headingloadfun=function(qbId){
		        var times=0;
		        var defattr=false;
		        var qbtabid="";
		        angular.forEach(qbTabs, function(value, key){
        	        if(((angular.element(value).attr("default"))==="open")&&(!times))
        	        {
        	           defattr=true;
        	           qbtabid=angular.element(value).children().attr("qb-tab-id");
        	           times=1;
        	        }
        	    });
        	    if(!(defattr))
        	    {
        	        qbtabid=angular.element(qbTabs[0]).children().attr("qb-tab-id");
        	    }
    		    angular.forEach(qbTabHeadings, function(value, key){
    		        var headId=angular.element(value).children().attr("qb-tab-id");
    		        if(headId===qbId)
    		        {
    		            angular.element(value).children().scope().openHeadingClass();
    		            var tabHeading=angular.element(value).children().scope().getHeading();
    		            var tabHeadingClass=angular.element(value).children().scope().headingClass();
    		            var thisHeadings=angular.element(element).children().children().children();
    		            angular.forEach(thisHeadings, function(value1, key1){
    		                if(angular.element(value1).scope().qbid)
    		                {
    		                    if((angular.element(value1).scope().qbid)===qbId)
    		                    {
    		                        angular.element(value1).attr("qb-tab-id",qbId);
    		                        angular.element(value1).addClass(tabHeadingClass);
    		                        angular.element(value1).append(tabHeading);
    		                        
    		                        var thisPaddingLeft=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('padding-left'));
                	                var thisPaddingRight=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('padding-right'));
                	                var thisMarginLeft=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('margin-left'));
                	                var thisMarginRight=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('margin-right'));
                	                var thisBorderLeft=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('border-left'));
                	                var thisBorderRight=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('border-right'));
                	                
                	                var thisTotalWidth=thisPaddingLeft+thisPaddingRight+thisMarginLeft+thisMarginRight+thisBorderLeft+thisBorderRight+headingSize;
                	                angular.element(element).children().scope().headingStyle(thisTotalWidth);
    		                    }
    		                }
    		            }); 
    		        }
    		        if(qbtabid===qbId)
    		        {
    		            angular.element(element).children().scope().clickfun(qbtabid);
    		        }
    		    }); 
		    };
		    
		    scope.clickfun=function(qbId){
		        angular.forEach(qbTabContents, function(value, key){
		            if((angular.element(value).children().attr("qb-tab-id"))===qbId)
		            {
		                angular.element(value).children().scope().tabopen();          
		            }
		            else
		            {
		                angular.element(value).children().scope().tabclose();
		            }
		        }); 
		        var thisHeadings=angular.element(element).children().children().children();
                angular.forEach(thisHeadings, function(value1, key){
                    if(angular.element(value1).hasClass("qb-tab-heading-active"))
                    {
                        angular.element(value1).removeClass("qb-tab-heading-active").addClass("qb-tab-heading-inactive");
                    }
                    if(angular.element(value1).scope().qbid)
                    {
                        if((angular.element(value1).scope().qbid)===qbId)
                        {
                            angular.element(value1).addClass("qb-tab-heading-active").removeClass("qb-tab-heading-inactive");
                        }
                    }
                });
		    };
		},
		template: function(element,attr){ 
		    return  "<div class=\"qb-tabs\">"+ 
		                "<div class=\"qb-tab-headings\" style=\"overflow:hidden;width:auto\">"+
		                    " <div ng-repeat=\"qbid in qbidies\" class=\"qb-tab-heading qb-tab-heading-inactive ng-isolate-scope ng-scope\" ng-init=\"headingloadfun(qbid)\" ng-click=\"clickfun(qbid)\" ></div> "+
		                "</div>"+
		                "<div class=\"qb-tab-contents\" ng-transclude ></div>"+
		            "</div>";
		}
	}
}]);
myApp.directive('qbTab',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
	    
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-tab\" ng-transclude ></div>";
		}
	}
}]);
myApp.directive('qbTabHeading',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    scope.headingClass=function(){
		        if(attr.classes)
    		    {
    		        var headingClass=qbBasics.classCons(attr.classes);
    		        return headingClass;
    		    }
    		    else
    		    {
    		        return undefined;
    		    }
		    };
		    scope.getHeading=function(){
		        return transclude();
		    };
		    scope.openHeadingClass=function(){
		        if(attr.qbTabOpenClasses)
		        {
		            var headingClass=qbBasics.classCons(attr.qbTabOpenClasses);
    		        return headingClass;
		        }
		        else
		        {
		            return undefined; 
		        }
		    };
		},
		template: function(element,attr){ 
		    return "<div style=\"display:none;\" ng-transclude></div>";
		}
	}
}]);
myApp.directive('qbTabContent',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    scope.tabopen=function(){
		        angular.element(element).children().addClass("qb-tab-content-open").removeClass("qb-tab-content-close");
		    };
		    
		    scope.tabclose=function(){
		        angular.element(element).children().addClass("qb-tab-content-close").removeClass("qb-tab-content-open");
		    };
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-tab-content\" ng-transclude></div>";
		}
	}
}]);

//Work On Progress Last Seen 16-07-19
/*
myApp.directive('qbTabs',['qbBasics', function(qbBasics) {
    return {
	    scope: {},
		transclude: true,
		link: function(scope,element,attr){
		    var qbTabs=qbBasics.findChildren(angular.element(element),"QB-TAB");
		    var qbTabHeadings=qbBasics.findChildren(angular.element(element),"QB-TAB-HEADING");
		    var qbTabContents=qbBasics.findChildren(angular.element(element),"QB-TAB-CONTENT");
		    var numOfHeadings=qbTabHeadings.length;
		    scope.qbidies=[];
		    var i=0;
		    angular.forEach(qbTabs, function(value, key){
		        scope.qbidies.push("qb-tab-"+i);
		        angular.element(qbTabs[i]).children().attr("qb-tab-id",scope.qbidies[i]);
		        angular.element(qbTabHeadings[i]).children().attr("qb-tab-id",scope.qbidies[i]);
		        angular.element(qbTabContents[i]).children().attr("qb-tab-id",scope.qbidies[i]);
		        i++;
		    });
		    
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    
            var headingAllign="";
            var headingSizeType="";
            var headingTotalWidth="";
            var headingComputedWidth="";
            var headingGivenWidth="";
            if(attr.qbHeadingsStyle)
		    {
		        var qbHeadStyles=attr.qbHeadingsStyle.split(";");
		        angular.forEach(qbHeadStyles, function(value, key){
		            var qbHeadStyle="";
		            qbHeadStyle=value.split(":");
		            if((qbHeadStyle[0])==="allign")
		            {
		                if((qbHeadStyle[1])==="left")
		                {
		                    headingAllign="left";
		                }
		                else if((qbHeadStyle[1])==="right")
		                {
		                    headingAllign="right";
		                }
		                else if((qbHeadStyle[1])==="centre")
		                {
		                    headingAllign="centre";
		                }
		            }
		            else if((qbHeadStyle[0])==="size")
		            {
		                if((qbHeadStyle[1])==="equal")
		                {
		                    headingSizeType="equal";
		                    //angular.element(element).children().scope().headingSize(headSize,"equal");
		                }
		                else if((qbHeadStyle[1])==="auto")
		                {
		                    headingSizeType="auto";
		                }
		                else if((qbHeadStyle[1])==="fullfill")
		                {
		                    headingSizeType="fullfill";
		                }
		            }
		            else if((qbHeadStyle[0])==="total-width") 
		            {
		                if(qbHeadStyle[1])
		                {
		                    headingTotalWidth=qbHeadStyle[1];
		                }
		            }
		        });
		        if(headingTotalWidth)
		        {
		            var tempEle=angular.element("<div> hhd shuks kjh</div>");
		            tempEle[0].style.width=headingTotalWidth;
		            angular.element(element).append(tempEle);
		            headingGivenWidth=window.getComputedStyle(angular.element(element).children()[1], null).getPropertyValue('width');
    	            tempEle.remove();
    	            
    	            angular.element(element).children().children()[0].style.width="100%";
    	            var headingCont=angular.element(angular.element(element).children().children()[0]);
    	            headingComputedWidth=parseFloat(window.getComputedStyle(headingCont[0], null).getPropertyValue('width'));
		        }
		        else
		        {
		            angular.element(element).children().children()[0].style.width="100%";
    	            var headingCont=angular.element(angular.element(element).children().children()[0]);
    	            headingComputedWidth=parseFloat(window.getComputedStyle(headingCont[0], null).getPropertyValue('width'));
		            headingGivenWidth=window.getComputedStyle(angular.element(element).children()[1], null).getPropertyValue('width');
		        }
		    } 
		    
		    
		    var headingSize=0;
		    scope.headingStyle=function(headWidth){
		        //size type
		        if(headingSizeType==="fullfill")
		        {
		            if(headingTotalWidth)
        	        {
        	            console.log(headingGivenWidth);
        	            var headingWidth=(headingGivenWidth)/(numOfHeadings);
        	            
        	            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		                angular.forEach(headingDivs, function(value, key){
        	                var thisPaddingLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-left'));
        	                var thisPaddingRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-right'));
        	                var thisMarginLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-left'));
        	                var thisMarginRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-right'));
        	                var thisBorderLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-left'));
        	                var thisBorderRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-right'));
        	                
        	                var thisCalculatedWidth=headingWidth-(thisPaddingLeft+thisPaddingRight+thisMarginLeft+thisMarginRight+thisBorderLeft+thisBorderRight);
        	                angular.element(value).children().css("width",thisCalculatedWidth+"px");
        	            });
        	        }
        	        else
        	        {
        	            console.log(headingGivenWidth);
        	            var headingWidth=(headingGivenWidth)/(numOfHeadings);
        	            
        	            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		                angular.forEach(headingDivs, function(value, key){
        	                var thisPaddingLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-left'));
        	                var thisPaddingRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-right'));
        	                var thisMarginLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-left'));
        	                var thisMarginRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-right'));
        	                var thisBorderLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-left'));
        	                var thisBorderRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-right'));
        	                
        	                var thisCalculatedWidth=headingWidth-(thisPaddingLeft+thisPaddingRight+thisMarginLeft+thisMarginRight+thisBorderLeft+thisBorderRight);
        	                angular.element(value).children().css("width",thisCalculatedWidth+"px");
        	            });
        	        }
		        }
		        else if(headingSizeType==="equal")
		        {
		            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		            if(headWidth>headingSize)
    		        {
    		            headingSize=headWidth;
    		        }
    		        angular.forEach(headingDivs, function(value, key){
    	                //all values of padding margin border
    	                var thisPaddingLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-left'));
    	                var thisPaddingRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('padding-right'));
    	                var thisMarginLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-left'));
    	                var thisMarginRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('margin-right'));
    	                var thisBorderLeft=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-left'));
    	                var thisBorderRight=parseFloat(window.getComputedStyle(angular.element(value)[0], null).getPropertyValue('border-right'));
    	                
    	                var thisTotalWidth=thisPaddingLeft+thisPaddingRight+thisMarginLeft+thisMarginRight+thisBorderLeft+thisBorderRight+headingSize;
    	                angular.element(value).children().css("width",thisTotalWidth+"px");
    	            });   
		        }
		        else if(headingSizeType==="auto")
		        {
		            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		            angular.forEach(headingDivs, function(value, key){
		                angular.element(value).css("width","auto");
    	            });
		        }
		        
		        //total width
		        if(headingTotalWidth)
		        {
		            
		        }
		        
		        // allignment
		        if(headingAllign==="left")
		        {
		            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		            angular.forEach(headingDivs, function(value, key){
		                angular.element(value).css("float","left");
    	            });
    	            var paddingRight=headingComputedWidth-headingGivenWidth;
    	            angular.element(angular.element(element).children().children()[0]).css("padding-right",paddingRight+"px");
    	            
    	        }
		        else if(headingAllign==="right")
		        {
		            angular.element(element).children().children()[0].style.width="100%";
		            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		            angular.forEach(headingDivs, function(value, key){
		                angular.element(value).css("float","left");
    	            });
    	            var paddingLeft=headingComputedWidth-headingGivenWidth;
    	            angular.element(angular.element(element).children().children()[0]).css("padding-left",paddingLeft+"px");
		        }
		        else if(headingAllign==="centre")
		        {
		            angular.element(element).children().children()[0].style.width="100%";
		            var headingDivs=angular.element(angular.element(element).children().children()[0]).children();
		            angular.forEach(headingDivs, function(value, key){
		                angular.element(value).css("float","left");
    	            });
    	            var padding=(headingComputedWidth-headingGivenWidth)/2;
    	            angular.element(angular.element(element).children().children()[0]).css("padding-right",padding+"px");
    	            angular.element(angular.element(element).children().children()[0]).css("padding-left",padding+"px");
		        }
		    };
		    
		    scope.headingloadfun=function(qbId){
		        var times=0;
		        var defattr=false;
		        var qbtabid="";
		        angular.forEach(qbTabs, function(value, key){
        	        if(((angular.element(value).attr("default"))==="open")&&(!times))
        	        {
        	           defattr=true;
        	           qbtabid=angular.element(value).children().attr("qb-tab-id");
        	           times=1;
        	        }
        	    });
        	    if(!(defattr))
        	    {
        	        qbtabid=angular.element(qbTabs[0]).children().attr("qb-tab-id");
        	    }
    		    angular.forEach(qbTabHeadings, function(value, key){
    		        var headId=angular.element(value).children().attr("qb-tab-id");
    		        if(headId===qbId)
    		        {
    		            angular.element(value).children().scope().openHeadingClass();
    		            var tabHeading=angular.element(value).children().scope().getHeading();
    		            var tabHeadingClass=angular.element(value).children().scope().headingClass();
    		            var thisHeadings=angular.element(element).children().children().children();
    		            angular.forEach(thisHeadings, function(value1, key1){
    		                if(angular.element(value1).scope().qbid)
    		                {
    		                    if((angular.element(value1).scope().qbid)===qbId)
    		                    {
    		                        angular.element(value1).attr("qb-tab-id",qbId);
    		                        angular.element(value1).children().addClass(tabHeadingClass);
    		                        angular.element(value1).children().append(tabHeading);
    		                        
    		                        var thisPaddingLeft=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('padding-left'));
                	                var thisPaddingRight=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('padding-right'));
                	                var thisMarginLeft=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('margin-left'));
                	                var thisMarginRight=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('margin-right'));
                	                var thisBorderLeft=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('border-left'));
                	                var thisBorderRight=parseFloat(window.getComputedStyle(angular.element(value1)[0], null).getPropertyValue('border-right'));
                	                
                	                var thisTotalWidth=thisPaddingLeft+thisPaddingRight+thisMarginLeft+thisMarginRight+thisBorderLeft+thisBorderRight+headingSize;
                	                angular.element(element).children().scope().headingStyle(thisTotalWidth);
    		                    }
    		                }
    		            }); 
    		        }
    		        if(qbtabid===qbId)
    		        {
    		            angular.element(element).children().scope().clickfun(qbtabid);
    		        }
    		    }); 
		    };
		    
		    scope.clickfun=function(qbId){
		        angular.forEach(qbTabContents, function(value, key){
		            if((angular.element(value).children().attr("qb-tab-id"))===qbId)
		            {
		                angular.element(value).children().scope().tabopen();          
		            }
		            else
		            {
		                angular.element(value).children().scope().tabclose();
		            }
		        }); 
		        var thisHeadings=angular.element(element).children().children().children();
                angular.forEach(thisHeadings, function(value1, key){
                    if(angular.element(value1).children().hasClass("qb-tab-heading-active"))
                    {
                        angular.element(value1).children().removeClass("qb-tab-heading-active").addClass("qb-tab-heading-inactive");
                    }
                    if(angular.element(value1).scope().qbid)
                    {
                        if((angular.element(value1).scope().qbid)===qbId)
                        {
                            angular.element(value1).children().addClass("qb-tab-heading-active").removeClass("qb-tab-heading-inactive");
                        }
                    }
                });
		    };
		},
		template: function(element,attr){ 
		    return  "<div class=\"qb-tabs\">"+ 
		                "<div class=\"qb-tab-headings\">"+
		                    " <div ng-repeat=\"qbid in qbidies\" class=\" ng-isolate-scope ng-scope\" ng-init=\"headingloadfun(qbid)\" ng-click=\"clickfun(qbid)\" ><div class=\"qb-tab-heading qb-tab-heading-inactive\"></div></div> "+
		                "</div>"+
		                "<div class=\"qb-tab-contents\" ng-transclude ></div>"+
		            "</div>";
		}
	}
}]);
myApp.directive('qbTab',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
	    
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-tab\" ng-transclude ></div>";
		}
	}
}]);
myApp.directive('qbTabHeading',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    scope.headingClass=function(){
		        if(attr.classes)
    		    {
    		        var headingClass=qbBasics.classCons(attr.classes);
    		        return headingClass;
    		    }
    		    else
    		    {
    		        return undefined;
    		    }
		    };
		    scope.getHeading=function(){
		        return transclude();
		    };
		    scope.openHeadingClass=function(){
		        if(attr.qbTabOpenClasses)
		        {
		            var headingClass=qbBasics.classCons(attr.qbTabOpenClasses);
    		        return headingClass;
		        }
		        else
		        {
		            return undefined; 
		        }
		    };
		},
		template: function(element,attr){ 
		    return "<div style=\"display:none;\" ng-transclude></div>";
		}
	}
}]);
myApp.directive('qbTabContent',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    scope.tabopen=function(){
		        angular.element(element).children().addClass("qb-tab-content-open").removeClass("qb-tab-content-close");
		    };
		    
		    scope.tabclose=function(){
		        angular.element(element).children().addClass("qb-tab-content-close").removeClass("qb-tab-content-open");
		    };
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-tab-content\" ng-transclude></div>";
		}
	}
}]);
*/
//its not working last seen on 23-03-19
/*myApp.directive('qbTabs',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    scope.headings=[];
		    var rt=1;
		    var defHeading;
		    var headEles=[];
    		var child=qbBasics.findChildren(angular.element(element),"QB-TAB");
		    var headings=qbBasics.findChildren(angular.element(element),"qb-tab-heading");
		    var h=0;
		    angular.forEach(angular.element(headings).children(), function(value, key){
		        scope.headings.push(angular.element(value).html());
		        headEles[h]=angular.element(value).scope().transfun();
		        h++;
		    });
		    
		    //find def heading
		    angular.forEach(child, function(value, key){
		        if((angular.element(value).attr("default"))&&(rt))
		        {
		            var tabHead=qbBasics.findChildren(angular.element(value),"qb-tab-heading");
		            defHeading=angular.element(tabHead).children().html();
		            angular.element(value).children().css("display","block");
		            rt=0;
		        }
		        else
		        {
		            angular.element(value).children().css("display","none");
		        }
		    });
		    if(rt)
		    {
		        angular.forEach(child, function(value, key){
		            if(rt)
		            {
		                var tabHead=qbBasics.findChildren(angular.element(value),"qb-tab-heading");
		                defHeading=angular.element(tabHead).children().html();
		                angular.element(value).children().css("display","block");
		                rt=0;
		            }
		        });    
		    }
		    
		    scope.tabopen=function(heading){
		        var i=0;
		        var childHead=angular.element(element).children().children();
		        angular.forEach(childHead, function(value, key){
		            if(angular.element(value).hasClass("qb-tab-heading"))
    		        {
    		            if(scope.headings[i]===heading)
    		            {
    		                angular.element(value).addClass("qb-tab-heading-active");
    		            }
    		            else
    		            {
    		                angular.element(value).removeClass("qb-tab-heading-active");
    		            }
    		        }
    		        i++;
    		    });
    		    var contents=qbBasics.findChildren(angular.element(element),"qb-tab-content");
		        angular.forEach(child, function(value, key){
		            var tabHeading=angular.element(qbBasics.findChildren(angular.element(value),"qb-tab-heading")).children().html();
    		        if(tabHeading===heading)
    		        {
    		            angular.element(value).children().scope().tabopen();
    		        }
    		        else
    		        {
    		            angular.element(value).children().scope().tabclose();
    		        }
    		    });
		    };
		    
		    scope.loadfun=function(heading){
		        var i=0;
		        var childHead=angular.element(element).children().children();
		        angular.forEach(childHead, function(value, key){
		            if(angular.element(value).hasClass("qb-tab-heading"))
    		        {
    		            if(scope.headings[i]===defHeading)
    		            {
    		                angular.element(value).addClass("qb-tab-heading-active");
    		            }
    		            alert(headEles[i]);
    		            angular.element(value).append(headEles[i]);
    		        }
    		        i++;
    		    });
		    };
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-tabs\"> <div ng-repeat=\"heading in headings\" class=\"qb-tab-heading ng-isolate-scope ng-scope\" ng-click=\"tabopen(heading)\" ng-init=\"loadfun(heading)\"></div> </div> <div class=\"nothing\" ng-transclude ></div>";
		}
	}
}]);
myApp.directive('qbTab',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    
		    scope.tabopen=function(){
		        angular.element(element).children().css("display","block");
		    };
		   
		    scope.tabclose=function(){
		        angular.element(element).children().css("display","none");
		    };
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-tab\" ng-transclude ></div>";
		}
	}
}]);
myApp.directive('qbTabHeading',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope, element, attr, ctrl, transclude){
		    scope.transfun=function(){
		        return transclude();
		    };
		},
		template: function(element,attr){ 
		    return "<div style=\"display:none;\" ng-transclude></div>";
		}
	}
}]);
myApp.directive('qbTabContent',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-tab-content\" ng-transclude></div>";
		}
	}
}]);*/

//last seen on 23-03-19
/*myApp.directive('qbTabs', function() {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
		    var valu=0;
		    scope.headings=[];
		    scope.tabFlag=0;
		    angular.element(element).scope().tabFlag=0;
		    //alert(angular.element(element).scope().tabFlag);
		    var tabsP=angular.element(element).children();
		    angular.forEach(tabsP, function(val2, key){
	            if(!(angular.element(val2).hasClass("tabs")))
                {
                    var tabs=angular.element(val2).children();
	                angular.forEach(tabs, function(val3, key){
	                    scope.headings.push(angular.element(val3).children().scope().heading);
		          });
	            }
	        });
	        element.on(
                        "click",
                        function handleClickEvent( event ) {
                            var head=angular.element(event.target).scope().heading;
                            var tabsP=angular.element(element).children();
            		        angular.forEach(tabsP, function(val2, key){
            	                if(!(angular.element(val2).hasClass("tabs")))
                                {
                                    var tabs=angular.element(val2).children();
            	                    angular.forEach(tabs, function(val3, key){
            	                        var tab=angular.element(val3).children();
            	                        if((angular.element(val3).children().scope().heading)===head)
            	                            {
            	                                if(tab.hasClass("tabContentClose"))
                	                            tab.removeClass("tabContentClose").addClass("tabContentOpen");
            	                            }
            	                        else
            	                        {
            	                            tab.removeClass("tabContentOpen").addClass("tabContentClose");
            	                        }
            		                 });
            	                }
            	           });      
                        });
		},
		template: function(element,attr){
		    return "<div class=\"tabs\"> <div ng-repeat=\"heading in headings\" class=\"tab\">{{heading}}</div> </div> <div ng-transclude ></div>";
		}
	}
  });
  
myApp.directive('qbTab', function() {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
		        scope.heading=attr.heading;
		        scope.class="tabContentClose";
		        scope.val=5;
		        var valu=0;
		        var defs=angular.element(element).parent().parent().children().children().children();
		        angular.forEach(defs, function(val3, key){
                    if(valu==0)
	                {
	                    angular.element(val3).scope().class="tabContentOpen";
		                valu++;
		            }
		        });
		    },
		template: function(element,attr){
		    return "<div ng-transclude class={{class}}></div>";
		}
	}
});*/


//it might work testing left
myApp.directive('qbTabs',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    
		    scope.initclass=function(classes,heading){
		        //alert(heading+classes);
		    };
		    
		    scope.headings=[];
		    scope.headClasses=[];
		    var rt=1;
		    var headings=[];
		    var defHeading;
    		var child=qbBasics.findChildren(angular.element(element),"QB-TAB");
		    var headingEles=qbBasics.findChildren(angular.element(element),"qb-tab-heading");
		    var int1=0;
		    angular.forEach(angular.element(headingEles), function(value, key){
		        scope.headings.push(angular.element(value).children().html());
		        headings[int1]=angular.element(value).children().html();
		        if(angular.element(value).attr("classes"))
		        {
		            var tabHclass=qbBasics.classCons(angular.element(value).attr("classes"));
		            scope.headClasses.push(tabHclass);
		        }
		        else
		        {
		            scope.headClasses.push("nothing");
		        }
		        int1++;
		    });
		    
		    //find def heading
		    angular.forEach(child, function(value, key){
		        if((angular.element(value).attr("default"))&&(rt))
		        {
		            var tabHead=qbBasics.findChildren(angular.element(value),"qb-tab-heading");
		            defHeading=angular.element(tabHead).children().html();
		            angular.element(value).children().css("display","block");
		            rt=0;
		        }
		        else
		        {
		            angular.element(value).children().css("display","none");
		        }
		    });
		    if(rt)
		    {
		        angular.forEach(child, function(value, key){
		            if(rt)
		            {
		                var tabHead=qbBasics.findChildren(angular.element(value),"qb-tab-heading");
		                defHeading=angular.element(tabHead).children().html();
		                angular.element(value).children().css("display","block");
		                rt=0;
		            }
		        });    
		    }
		    
		    scope.tabopen=function(heading){
		        var i=0;
		        var childHead=angular.element(element).children().children();
		        angular.forEach(childHead, function(value, key){
		            if(angular.element(value).hasClass("qb-tab-heading"))
    		        {
    		            if(scope.headings[i]===heading)
    		            {
    		                angular.element(value).addClass("qb-tab-heading-active");
    		            }
    		            else
    		            {
    		                angular.element(value).removeClass("qb-tab-heading-active");
    		            }
    		        }
    		        i++;
    		    });
    		    var contents=qbBasics.findChildren(angular.element(element),"qb-tab-content");
		        angular.forEach(child, function(value, key){
		            var tabHeading=angular.element(qbBasics.findChildren(angular.element(value),"qb-tab-heading")).children().html();
    		        if(tabHeading===heading)
    		        {
    		            angular.element(value).children().scope().tabopen();
    		        }
    		        else
    		        {
    		            angular.element(value).children().scope().tabclose();
    		        }
    		    });
		    };
		    
		    scope.loadfun=function(heading){
		        var i=0;
		        var childHead=angular.element(element).children().children();
		        angular.forEach(childHead, function(value, key){
		            if(angular.element(value).hasClass("qb-tab-heading"))
    		        {
    		            if(scope.headings[i]===defHeading)
    		            {
    		                angular.element(value).addClass("qb-tab-heading-active");
    		            }
    		        }
    		        i++;
    		    });
    		    
    		    var j=0;
    		    angular.forEach(childHead, function(value, key){
		            if(angular.element(value).hasClass("qb-tab-heading"))
    		        {
    		            if(scope.headings[j]===heading)
    		            {
    		                angular.element(value).html(scope.headings[j]);
    		                if(scope.headClasses[j]!="nothing")
    		                {
    		                    var headEleClass=scope.headClasses[j];
    		                    angular.element(value).addClass(headEleClass);
    		                }
    		            }
    		        }
    		        j++;
    		    });
    		    angular.element(element).children().children().append("<div style=\"clear:both\"></div>");
		        //alert(angular.element(element).children()[0].offsetHeight);
		    };
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-tabs\"> <div ng-repeat=\"heading in headings\" class=\"qb-tab-heading ng-isolate-scope ng-scope\" ng-click=\"tabopen(heading)\" ng-init=\"loadfun(heading)\"></div> </div> <div style=\"clear:both\"></div> <div class=\"nothing\" ng-transclude ></div>";
		}
	}
}]);
myApp.directive('qbTab',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		    
		    scope.tabopen=function(){
		        angular.element(element).children().css("display","block");
		    };
		   
		    scope.tabclose=function(){
		        angular.element(element).children().css("display","none");
		    };
		    angular.element(element).children().children().append("<div style=\"clear:both\"></div>");
		},
		template: function(element,attr){ 
		    return "<div ng-transclude class=\"qb-tab\"></div>";
		}
	}
}]);
myApp.directive('qbTabHeading',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
	        
		},
		template: function(element,attr){ 
		    return "<div style=\"display:none;\" ng-init=\"initfun()\" ng-transclude></div>";
		}
	}
}]);
myApp.directive('qbTabContent',['qbBasics', function(qbBasics) {
    return {
		scope: {},
		transclude: true,
		link: function(scope,element,attr){
		    if(attr.classes)
		    {
		        angular.element(element).children().addClass(qbBasics.classCons(attr.classes));
		    }
		},
		template: function(element,attr){ 
		    return "<div class=\"qb-tab-content\" ng-transclude></div>";
		}
	}
}]);