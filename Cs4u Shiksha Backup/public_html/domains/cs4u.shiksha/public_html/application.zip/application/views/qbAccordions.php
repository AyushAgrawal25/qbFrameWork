<div class="qb-accordions">
    <div class="qb-accordion">
        <div class="qb-accordion-heading"></div>
        <div class="qb-accordion-content"></div>
    </div>
    <div class="qb-accordion">
        <div class="qb-accordion-heading"></div>
        <div class="qb-accordion-content"></div>
    </div>
    <div class="qb-accordion">
        <div class="qb-accordion-heading"></div>
        <div class="qb-accordion-content"></div>
    </div>
</div>
<!--    <div class="container">
            <div class="accordion">
                <div class="holder">
                    <div class="heading">accordion 1</div>
                    <div class="icon active">+</div>
                    <div class="icon inactive">-</div>
                </div>
                <div class="content active">
                    accordion one is good ...you can trust him
                </div>
            </div>
            <div class="accordion">
                <div class="holder">
                    <div class="heading">accordion 2</div>
                    <div class="icon active">+</div>
                    <div class="icon inactive">-</div>
                </div>
                <div class="content active">
                    accordion 2 is nice......having a good habbit of playing football
                </div>
            </div>
        </div>-->