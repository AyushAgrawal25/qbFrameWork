<?php
$views['header']='header';
$views['footer']='footer';
