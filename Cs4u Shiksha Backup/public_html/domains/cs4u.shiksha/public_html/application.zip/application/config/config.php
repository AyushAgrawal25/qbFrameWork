<?php
//url configration
$config['baseurl']='http://localhost/dictonary_site/';

//mailer configration
$config['mailhost']='fastlinux.cms500.com';
$config['mailport']='465';

