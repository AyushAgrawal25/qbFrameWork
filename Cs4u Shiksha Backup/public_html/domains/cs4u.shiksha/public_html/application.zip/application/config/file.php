<?php
$file['name']="";
$file['width']=0;
$file['height']=0;
$file['type']="all";
$file['X']=0;
$file['Y']=0;
