<?php
$database['host']='localhost';
$database['database']='csushiks_jaimatadee';
$database['user']='csushiks_db_user';
$database['password']='=~HlS2babCN#';
?>