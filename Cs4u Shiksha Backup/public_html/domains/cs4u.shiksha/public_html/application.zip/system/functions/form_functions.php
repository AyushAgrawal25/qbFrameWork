<?php
if ( ! function_exists('testfunction'))
{
	function testfunction()
	{
		echo "testfunction...";
	}
}
